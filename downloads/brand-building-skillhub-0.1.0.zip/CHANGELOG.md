# Changelog

## 0.1.0

- Standalone brand-building Skill repository with a versioned GitHub release.
- Owns brand plan/execute/resume, research, expression, distribution, the additional 34 method entries, and the T1–T10 teaching map.
- References the original 26 M1–M8 method IDs through a reviewed agent-readiness pin. Does not duplicate that baseline as authored source.
- Brand research works from the source checkout without installing the dependency. Website work reports a missing dependency instead of fetching latest.
- Ships fictional brand-project templates. Owner-filled project Markdown stays private.
- `publication_status` is `released`. `dependency-lock.json` pins commit, version `0.7.0`, and the skillhub SHA-256.

- Publish the versioned GitHub package and the Skills catalog download; keep third-party marketplace status separate.
