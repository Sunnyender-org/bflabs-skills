# Brand Building

独立仓库，版本 **0.1.0**。本包是本地候选，**尚未远程发布**。

为一个品牌、一个市场做研究、定位、表达和分发。可以先做，不必先有网站。网站诊断、GEO 轮次和内容合同仍由 pinned 的 `bflabs-agent-readiness` 负责，不在本仓库复制工具源码。

## 这个仓库负责什么

| 本仓库 | pinned agent-readiness |
| --- | --- |
| 品牌计划、执行、续跑 | 网站诊断与六个网站子 Skill |
| 定位、表达、分发参考 | 网站基础、单站 round、到站问卷 |
| 新增 34 条方法（含 M1–M8 内新增条目与 M9–M13） | 原 M1–M8 基线 26 条方法 |
| T1–T10 教学顺序（不是运行清单） | 网站打包与校验程序 |
| 两份项目模板：简报、工作记录 | 内容合同、geo-content、方法复核表 |

所有权说明见 [docs/ownership.md](docs/ownership.md)。

## 没有网站也可以开始

源码检出本身就能做品牌研究：复制 `templates/brand-brief.md` 和 `templates/brand-work.md` 到主人的**项目目录**。那两份填好的记录保持私有，不要提交到本仓库。

虚构示例在 `templates/examples/brand-project/`，不是真实案例。

## 本地安装（从本仓库产出的 zip）

本版本没有远程安装地址。请从本仓库构建 zip，再按宿主的本地 Skill 方式加载。

1. 准备一份 **干净** 的 `bflabs-agent-readiness` 本地检出，其 `HEAD` 必须等于 [dependency-lock.json](dependency-lock.json) 里的完整 40 位 git 提交。目录名可以是 `main`，以 HEAD 为准。
2. 不要让安装程序去解析 `latest` 或未钉住的默认分支。
3. 在源码检出里生成依赖并打包：

```bash
python3 scripts/check_repository.py
python3 -m unittest discover -s tests
python3 scripts/package.py vendor --readiness-checkout <clean-pinned-checkout>
python3 scripts/package.py zip
```

若 readiness 构建器需要 jsonschema，把 `PYTHON` 设成带该依赖的解释器。`skillhub_sha256` 必须与 lock 一致。

产出：`dist/brand-building-skillhub-0.1.0.zip`。这是说明、模板、本包 `scripts/package.py`，以及 `dependencies/agent-readiness/` 网站资源。文件数不超过 200。

4. 在宿主的 skills 目录中新建 `brand-building` 文件夹，把 zip 内容解压进去，再加载 `brand-building/SKILL.md`。
5. 包版本是 **0.1.0**，所属仓库是 **brand-building**。不要把本包说成已经在远处上架。

`dependencies/` 是生成结果，不是源码，不要提交。

### zip 里有什么，没有什么

zip 是自洽的 Skill 资源包，不是完整离线 CLI 发行版。解压后可以用：

```bash
python3 scripts/package.py status
python3 scripts/package.py list
python3 scripts/package.py read references/brand-project.md
python3 scripts/package.py validate
```

`validate`（不带 --archive）核对已安装依赖；核对完整发行包用 `validate --archive <zip>`。

`list` / `read` 只开放 `SKILL.md`、`references/`、`templates/`、`evals/`。

完整的 `bflabs-readiness` 命令行不在这个 zip 里。若要安装那条命令行，使用 lock 里的具体 git 提交和版本，不要装 latest。没有它时，宿主仍可按内容合同写草稿。

## 网站任务缺依赖时

只做研究、定位和表达时，不需要先装依赖。源码路径是本仓库 `references/`。

一旦要做网站诊断、网站基础或按内容合同写页面，安装后的路径是：

- `dependencies/agent-readiness/skills/geo-content/SKILL.md`
- `dependencies/agent-readiness/skills/geo-content/references/content-contract.md`
- `dependencies/agent-readiness/skills/geo-content/references/brand-handoff.md`

目录不在时，报告缺口，并用上面的 `package.py vendor` 生成。不要默默拉取最新代码。没有校验程序时，宿主可以按同一证据规则写草稿，但不得写成校验已通过。

## 源码检出里的校验

```bash
python3 scripts/check_repository.py
python3 -m unittest discover -s tests
python3 scripts/run_evals.py
```

`check_repository.py` 和单元测试属于源码检出，不是给最终用户的离线 CLI。

可选：在已 vendor 的检出上生成阅读用合订本（不是第二份源码）：

```bash
python3 scripts/package.py assemble-method-book
```

## 许可

MIT。适用源码继承自原 agent-readiness 中可适用的 MIT 材料。第三方说明见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)。
