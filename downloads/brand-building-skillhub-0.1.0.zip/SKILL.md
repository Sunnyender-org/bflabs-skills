---
name: brand-building
description: Run evidence-bounded brand construction for one brand in one market. Use when planning, executing, or resuming brand research, positioning, expression, or distribution, including work that starts with no website. Not for ranking guarantees, paid rank-passing links, reciprocal first-place ranking, fake reviews, bulk SEO farms, website-only diagnosis, or claiming revenue without observed business evidence. Incremental claims require an appropriate comparison.
license: MIT
metadata:
  version: "0.1.0"
  short-description: Research, position, express, and distribute one brand in one market
  sunny_skill_type: library
---

# Brand Building

一次只做一个品牌、一个市场。可以先研究，不必先有网站。

网站能不能被找到、搜索里好不好看、生意有没有变好，要分开看。不要合成一个分数。首页上线或改完一批页面，都不等于品牌工作已经做完。

已经允许的本地工作继续做。还没允许的发布、发帖、访谈或花钱，只停这一项。声明要发布，不等于已经得到授权。

不知道就写不知道。不要把未知写成零，也不要编客户原话。

## 什么时候用

用这个 Skill，如果要做的是：

- 品牌建设、定位、识别或对外表达
- 还没有网站，先做研究和计划
- 继续已有的品牌简报和工作记录
- 判断这一阶段有没有做完

不要用这个 Skill 去保证排名、购买传权链接、互换第一名、批量造假评价，或在没有观察到的业务证据时声称带来了收入。增量需要合适对照。第一方订单可以当作业务证据。

只要检查公开网站、只改一个标题、只要网站基础方案、或只解释名词，不是品牌项目。

## 先留下两份记录

从模板复制到主人指定的**项目目录**，不要写进本仓库：

| 文件 | 模板 | 写什么 |
| --- | --- | --- |
| `brand-brief.md` | `templates/brand-brief.md` | 服务谁、替代方案、定位草案、关系、表达、假设、待确认 |
| `brand-work.md` | `templates/brand-work.md` | 阶段、授权、下一步、站外资产、分层证据 |

价格、退款、限制等会变的事实只写指针。虚构示例在 `templates/examples/brand-project/`，不是真实案例。

## 计划、执行、续跑

按当前缺口做，不要把 T1–T10 当成必须跑完的清单。

1. **计划**：写死品牌、市场、本阶段范围和明确不做。没有网站也可以输出带假设的草案。
2. **执行**：按需做研究、表达、一份可核验的核心资产、一个主要渠道的草稿。网站和搜索账户都不是开工前提。
3. **续跑**：先读工作记录的阶段、授权和下一步。已有授权不要再问一遍。已经发布并读回的网站动作不要重做。
4. **阶段完成**：约定范围都做了或标明不做、结果可核对、未做项仍看得到、下一步接得上。建设进度不能代替效果。

详细编排读 [references/brand-project.md](references/brand-project.md)。当前缺口才打开下面这些：

- 客户、购买情境、定位：[references/brand-research.md](references/brand-research.md)
- 名称、关系、语气：[references/brand-expression.md](references/brand-expression.md)
- 站外渠道、披露、纠错：[references/distribution-and-trust.md](references/distribution-and-trust.md)

本仓库方法条目在 [references/whitehat-method.md](references/whitehat-method.md)。教学顺序见 [references/method-map.json](references/method-map.json)，不是运行器。

## 没有网站时

继续做：公开替代方案、任务路径、定位草案、访谈提纲、表达禁区。访谈未授权就不要发出。不要发明域名。

用户其实只要建站时，不要强迫先做完定位。那是网站基础任务，需要 pinned agent-readiness。

## 源码检出和安装后的路径

源码检出里，品牌研究直接读本仓库 `references/` 和 `templates/`。网站工具不在源码树里。

安装本 Skill 的 zip 之后，网站工具在包内的 `dependencies/agent-readiness/`。写页面正文前读取：

- `dependencies/agent-readiness/skills/geo-content/SKILL.md`
- `dependencies/agent-readiness/skills/geo-content/references/content-contract.md`
- `dependencies/agent-readiness/skills/geo-content/references/brand-handoff.md`

若该目录不在，报告还缺 pinned 依赖，并说明要用干净、HEAD 等于 [dependency-lock.json](dependency-lock.json) 所钉提交的本地 checkout 运行 `python3 scripts/package.py vendor --readiness-checkout <checkout>`。不要跟踪 latest。品牌研究可以继续。没有可用校验程序时，宿主按同一证据规则写草稿，不要把草稿写成校验已通过。

zip 是说明、模板和网站资源包。完整 `bflabs-readiness` 命令行不在这个 zip 里；若需要，从 lock 里的具体提交安装，不要装 latest。没有那条命令行时，宿主草稿仍可使用。

## 证据怎么分开

| 层 | 能说明什么 | 不能冒充 |
| --- | --- | --- |
| 定位与认知 | 有没有说清服务谁、凭什么被考虑 | 市场已经记住我们 |
| 内容与网站 | 页面能不能完成真实任务 | 已被引用或带来收入 |
| 普通搜索 | 授权导出里的查询和页面 | 生成回答里的推荐 |
| 直接答案 / 生成答案 | 那一类入口上的观察 | 彼此相加，或当成订单来源 |
| 分发与声誉 | 真实发表、披露、纠错 | 发帖数等于权威 |
| 业务 | 授权记录里的激活、留存、实付和第一方订单 | 没有对照时的增量 |

准备度通过，不等于已被引用，也不等于已经产生收入。第一方订单是业务证据。没有合适对照，不能写成增量。

## 授权

读取公开资料、整理已有材料、写方案和草稿：直接做。

访谈邀请、客户消息、社区发帖、公开发布、生产部署、实际付款、接入分析账户：沿用已经记录的授权。缺授权只暂停该动作。

## 拒绝

购买传权链接。交换第一名。伪装独立评测。批量假账号或假评价。组织刷点击。给模型藏一套和真人不同的话。伪造权威或客户标志。把假设写成“客户说”。

<!-- AGENT_ONLY: Verify metadata.version 0.1.0 from this SKILL.md, not a summary. Plan/execute/resume/complete: references/brand-project.md. Load brand-research.md, brand-expression.md, and distribution-and-trust.md only for the current gap. Owned methods: references/whitehat-method.md (34 additional entries). Baseline M1–M8 26 IDs: dependencies/agent-readiness/references/whitehat-method.md after vendor; do not duplicate them. T1–T10 is teaching order, not a runtime checklist. Website diagnosis, site-foundation, geo-content, and round records live in the pinned dependency. Content contracts: dependencies/agent-readiness/skills/geo-content/references/content-contract.md and dependencies/agent-readiness/skills/geo-content/references/brand-handoff.md. If a website task is requested and the dependency is missing, report the gap and the vendor action; continue brand research. Host-drafted website copy is not a validator pass. publication_authorization is a declaration, not authorization. Copy templates into the owner's private project directory; do not commit filled brand-brief.md or brand-work.md here. Method review form is the pinned dependency templates/method-review.md. Examples must stay fictional. Never write workstation paths into public artifacts. -->
