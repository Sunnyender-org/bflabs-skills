"""Brand-building Skill package contracts."""

__version__ = "0.1.0"
