"""Pin, vendor, and zip contracts. Never resolve a floating latest pin."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from . import __version__
from .methods import FLOATING_PIN, PRIVATE_PATH
from .paths import dependency_lock_path, dependency_root, repository_root


SKILLHUB_MAX_FILES = 200
COMMIT_RE = re.compile(r"^[0-9a-f]{40}$")
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
TEXT_SUFFIXES = {
    "",
    ".css",
    ".csv",
    ".html",
    ".js",
    ".json",
    ".md",
    ".mjs",
    ".py",
    ".toml",
    ".txt",
    ".yaml",
    ".yml",
}
SKILL_ROOT_FILES = (
    "CHANGELOG.md",
    "CONTRIBUTING.md",
    "LICENSE",
    "README.md",
    "SECURITY.md",
    "SKILL.md",
    "THIRD_PARTY_NOTICES.md",
    "dependency-lock.json",
    "skill.yml",
)
SKILL_DIRS = ("agents", "docs", "evals", "references", "templates")
SKILL_RUNTIME_FILES = (
    "scripts/package.py",
    "src/brand_building/__init__.py",
    "src/brand_building/methods.py",
    "src/brand_building/packaging.py",
    "src/brand_building/paths.py",
)
SOP_ROOT_FILES = {"SKILL.md"}
SOP_DIRS = {"references", "templates", "evals"}
SOP_DENIED_ROOTS = {"scripts", "src", "dependencies", ".git"}
PRIVATE_PATTERNS = (
    (re.compile(rb"/(?:Users|home)/[^/\s]+/"), "private home path"),
    (re.compile(rb"[A-Za-z]:\\Users\\[^\\\s]+\\"), "private Windows home path"),
    (re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"), "private key"),
    (re.compile(rb"\bsk-[A-Za-z0-9_-]{20,}\b"), "API key shaped token"),
    (re.compile(rb"\bBearer\s+[A-Za-z0-9._~-]{20,}"), "bearer token"),
)
MISSING_DEPENDENCY_MESSAGE = (
    "网站相关工作需要 pinned agent-readiness 依赖，当前源码检出里没有。"
    "请提供干净且 HEAD 等于 dependency-lock.json 所钉提交的本地 checkout，"
    "运行 python3 scripts/package.py vendor --readiness-checkout <checkout>。"
    "不要使用 latest 或未钉住的远端默认分支。品牌研究、定位和表达可以继续，不必先装依赖。"
)


class PackageError(ValueError):
    """Raised when a pin, vendor, or archive contract would be violated."""


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def _require_commit(value: str, label: str) -> str:
    commit = str(value or "").strip().lower()
    if not COMMIT_RE.fullmatch(commit):
        raise PackageError("{} must be a full 40-character lowercase git SHA".format(label))
    return commit


def _require_sha256(value: str, label: str) -> str:
    digest = str(value or "").strip().lower()
    if not SHA256_RE.fullmatch(digest):
        raise PackageError("{} must be a 64-character SHA-256 hex digest".format(label))
    return digest


def load_lock(root: Optional[Path] = None) -> Dict[str, Any]:
    path = dependency_lock_path(root)
    lock = json.loads(path.read_text("utf-8"))
    dependency = lock.get("dependency") or {}
    commit = _require_commit(str(dependency.get("git_commit") or ""), "dependency git_commit")
    version = str(dependency.get("version") or "")
    if FLOATING_PIN.match(version) or not version:
        raise PackageError("dependency-lock.json must pin a concrete version, not latest")
    if lock.get("package_version") != __version__:
        raise PackageError("dependency-lock.json package_version must match this package")
    if dependency.get("pin_kind") != "reviewed":
        raise PackageError("dependency-lock.json pin_kind must be reviewed")
    digest = _require_sha256(str(dependency.get("skillhub_sha256") or ""), "skillhub_sha256")
    dependency["git_commit"] = commit
    dependency["skillhub_sha256"] = digest
    lock["dependency"] = dependency
    return lock


def _git(checkout: Path, *args: str) -> str:
    completed = subprocess.run(
        ["git", *args],
        cwd=checkout,
        text=True,
        capture_output=True,
        check=False,
    )
    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout).strip() or "git failed"
        raise PackageError(detail)
    return completed.stdout.strip()


def verify_readiness_checkout(checkout: Path, lock: Optional[Dict[str, Any]] = None) -> Dict[str, str]:
    if checkout is None:
        raise PackageError("readiness checkout is required; refusing to resolve latest")
    path = Path(checkout).expanduser()
    if not path.is_dir():
        raise PackageError("readiness checkout is not a directory: {}".format(path))
    if path.is_symlink():
        raise PackageError("readiness checkout must not be a symlink: {}".format(path))
    if not (path / ".git").exists():
        raise PackageError("readiness checkout is not a git worktree: {}".format(path))
    lock = lock or load_lock()
    expected = lock["dependency"]["git_commit"]
    expected_version = lock["dependency"]["version"]
    head = _git(path, "rev-parse", "HEAD").strip().lower()
    if head != expected:
        raise PackageError(
            "readiness HEAD {} does not match pinned commit {}".format(head, expected)
        )
    dirty = _git(path, "status", "--porcelain")
    if dirty:
        raise PackageError("readiness checkout is not clean; refuse to vendor a dirty tree")
    skill_yml = path / "skill.yml"
    if not skill_yml.is_file():
        raise PackageError("readiness checkout is missing skill.yml")
    version_line = re.search(r"(?m)^version:\s*(\S+)\s*$", skill_yml.read_text("utf-8"))
    if version_line is None or version_line.group(1) != expected_version:
        found = version_line.group(1) if version_line else "missing"
        raise PackageError(
            "readiness skill.yml version {} does not match pinned version {}".format(
                found, expected_version
            )
        )
    return {"head": head, "version": expected_version, "path": str(path.resolve())}


def _safe_zip_name(name: str) -> PurePosixPath:
    relative = PurePosixPath(name)
    if relative.is_absolute() or relative.anchor or ".." in relative.parts or not name:
        raise PackageError("unsafe archive member: {}".format(name))
    if name.endswith("/"):
        raise PackageError("archive directories are expanded from files only: {}".format(name))
    return relative


def _is_zip_symlink(info: zipfile.ZipInfo) -> bool:
    mode = (info.external_attr >> 16) & 0xFFFF
    return stat.S_ISLNK(mode) or ((info.external_attr >> 28) & 0xF) == 0xA


def iter_zip_files(archive: Path) -> Iterable[Tuple[PurePosixPath, bytes, int]]:
    with zipfile.ZipFile(archive) as bundle:
        for info in bundle.infolist():
            if info.is_dir() or info.filename.endswith("/"):
                continue
            if _is_zip_symlink(info):
                raise PackageError("archive contains a symlink: {}".format(info.filename))
            relative = _safe_zip_name(info.filename)
            yield relative, bundle.read(info), (info.external_attr >> 16) & 0xFFFF


def extract_skillhub_zip(archive: Path, dest: Path) -> List[Tuple[PurePosixPath, bytes]]:
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True, exist_ok=True)
    written: List[Tuple[PurePosixPath, bytes]] = []
    for relative, data, mode in iter_zip_files(archive):
        target = dest / Path(*relative.parts)
        try:
            target.resolve().relative_to(dest.resolve())
        except ValueError as exc:
            raise PackageError("extracted path escapes destination: {}".format(relative)) from exc
        if target.exists() or target.is_symlink():
            raise PackageError("refusing to overwrite or follow a link: {}".format(relative))
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        target.chmod(mode or 0o644)
        written.append((relative, data))
    return written


def _run_readiness_builder(checkout: Path, output_dir: Path) -> Path:
    script = checkout / "scripts" / "package.py"
    if not script.is_file():
        raise PackageError("readiness package builder is missing: scripts/package.py")
    python = os.environ.get("PYTHON") or sys.executable
    completed = subprocess.run(
        [python, str(script), "--target", "skillhub", "--output", str(output_dir)],
        cwd=checkout,
        text=True,
        capture_output=True,
        check=False,
    )
    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout).strip().splitlines()
        raise PackageError(
            "readiness skillhub build failed: {}".format(detail[-1] if detail else "unknown error")
        )
    archives = sorted(output_dir.glob("bflabs-agent-readiness-skillhub-*.zip"))
    if len(archives) != 1:
        raise PackageError("readiness builder did not produce exactly one skillhub zip")
    return archives[0]


def _dep_payload_files(dest: Path) -> Dict[str, bytes]:
    files: Dict[str, bytes] = {}
    for path in sorted(dest.rglob("*")):
        if not path.is_file():
            continue
        if path.is_symlink():
            raise PackageError("symlinks are not allowed in vendored dependency: {}".format(path))
        relative = PurePosixPath(path.relative_to(dest).as_posix()).as_posix()
        if relative == "FILE_MANIFEST.json":
            continue
        if relative in files:
            raise PackageError("duplicate dependency path: {}".format(relative))
        files[relative] = path.read_bytes()
    return files


def _write_json(path: Path, payload: Dict[str, Any]) -> bytes:
    data = (json.dumps(payload, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    path.write_bytes(data)
    return data


def verify_vendored_dependency(root: Optional[Path] = None) -> Path:
    base = (root or repository_root()).resolve()
    dest = dependency_root(base)
    if not dest.is_dir() or not (dest / "SKILL.md").is_file():
        raise PackageError(MISSING_DEPENDENCY_MESSAGE)
    lock = load_lock(base)
    provenance_path = dest / "PROVENANCE.json"
    manifest_path = dest / "FILE_MANIFEST.json"
    if not provenance_path.is_file() or not manifest_path.is_file():
        raise PackageError("vendored dependency is missing provenance or file manifest")
    provenance = json.loads(provenance_path.read_text("utf-8"))
    manifest = json.loads(manifest_path.read_text("utf-8"))
    expected = lock["dependency"]
    for document, label in ((provenance, "provenance"), (manifest, "file manifest")):
        if document.get("git_commit") != expected["git_commit"]:
            raise PackageError("{} git_commit does not match dependency-lock.json".format(label))
        if document.get("version") != expected["version"]:
            raise PackageError("{} version does not match dependency-lock.json".format(label))
        if document.get("source_archive_sha256") != expected["skillhub_sha256"]:
            raise PackageError("{} archive hash does not match dependency-lock.json".format(label))
        if document.get("pin_kind") != expected["pin_kind"]:
            raise PackageError("{} pin_kind does not match dependency-lock.json".format(label))
    listed = manifest.get("files") or []
    listed_paths = [item.get("path") for item in listed]
    if len(listed_paths) != len(set(listed_paths)):
        raise PackageError("dependency FILE_MANIFEST contains duplicate paths")
    actual = _dep_payload_files(dest)
    listed_map = {item["path"]: item["sha256"] for item in listed}
    if set(listed_map) != set(actual):
        raise PackageError("dependency FILE_MANIFEST coverage does not match files on disk")
    for relative, data in actual.items():
        if listed_map[relative] != sha256_bytes(data):
            raise PackageError("dependency file hash mismatch: {}".format(relative))
    if "LICENSE" not in actual:
        raise PackageError("vendored dependency is missing LICENSE")
    return dest


def vendor_readiness(checkout: Path, root: Optional[Path] = None) -> Path:
    base = (root or repository_root()).resolve()
    lock = load_lock(base)
    verify_readiness_checkout(checkout, lock)
    dest = dependency_root(base)
    expected_hash = lock["dependency"]["skillhub_sha256"]
    with tempfile.TemporaryDirectory(prefix="brand-readiness-") as tmp:
        archive = _run_readiness_builder(Path(checkout), Path(tmp))
        archive_hash = sha256_file(archive)
        if archive_hash != expected_hash:
            raise PackageError(
                "readiness skillhub sha256 {} does not match lock {}".format(archive_hash, expected_hash)
            )
        extract_skillhub_zip(archive, dest)
    license_src = Path(checkout) / "LICENSE"
    if license_src.is_file() and not (dest / "LICENSE").is_file():
        (dest / "LICENSE").write_bytes(license_src.read_bytes())
    provenance = {
        "schema_version": "1.0.0",
        "name": lock["dependency"]["name"],
        "version": lock["dependency"]["version"],
        "git_commit": lock["dependency"]["git_commit"],
        "pin_kind": lock["dependency"]["pin_kind"],
        "source_archive": archive.name,
        "source_archive_sha256": archive_hash,
        "generated_by": "brand-building {}".format(__version__),
        "license": "MIT",
    }
    _write_json(dest / "PROVENANCE.json", provenance)
    payload = _dep_payload_files(dest)
    manifest = {
        **provenance,
        "files": [
            {"path": relative, "sha256": sha256_bytes(data)}
            for relative, data in sorted(payload.items())
        ],
    }
    _write_json(dest / "FILE_MANIFEST.json", manifest)
    verify_vendored_dependency(base)
    return dest


def dependency_status(root: Optional[Path] = None) -> Dict[str, Any]:
    dest = dependency_root(root)
    if not dest.is_dir():
        return {"present": False, "ok": False, "path": str(dest), "message": MISSING_DEPENDENCY_MESSAGE}
    try:
        verify_vendored_dependency(root)
    except PackageError as exc:
        return {"present": True, "ok": False, "path": str(dest), "message": str(exc)}
    return {"present": True, "ok": True, "path": str(dest), "message": None}


def list_sop_files(root: Optional[Path] = None) -> List[str]:
    base = (root or repository_root()).resolve()
    names: List[str] = []
    skill = base / "SKILL.md"
    if skill.is_file():
        names.append("SKILL.md")
    for directory in sorted(SOP_DIRS):
        folder = base / directory
        if not folder.is_dir():
            continue
        for path in sorted(folder.rglob("*")):
            if path.is_file() and not path.is_symlink():
                names.append(path.relative_to(base).as_posix())
    return names


def read_sop_file(relative: str, root: Optional[Path] = None) -> str:
    base = (root or repository_root()).resolve()
    raw = str(relative or "")
    if not raw or Path(raw).is_absolute() or PurePosixPath(raw).is_absolute():
        raise PackageError("path is outside the readable SOP surface")
    posix = PurePosixPath(raw)
    if ".." in posix.parts or posix.anchor or posix.parts[0] in SOP_DENIED_ROOTS:
        raise PackageError("path is outside the readable SOP surface")
    if posix.as_posix() not in SOP_ROOT_FILES and posix.parts[0] not in SOP_DIRS:
        raise PackageError("path is outside the readable SOP surface")
    unresolved = base / Path(*posix.parts)
    if any(part.is_symlink() for part in (unresolved, *unresolved.parents) if part != base and base in part.parents):
        raise PackageError("symlinks are outside the readable SOP surface")
    path = unresolved.resolve()
    try:
        path.relative_to(base)
    except ValueError as exc:
        raise PackageError("path is outside the readable SOP surface") from exc
    if not path.is_file() or path.is_symlink():
        raise PackageError("path is outside the readable SOP surface")
    return path.read_text("utf-8")


def _skill_source_files(root: Path) -> List[Tuple[PurePosixPath, Path]]:
    files: List[Tuple[PurePosixPath, Path]] = []
    for name in SKILL_ROOT_FILES:
        path = root / name
        if not path.is_file():
            raise PackageError("skill package is missing required file: {}".format(name))
        files.append((PurePosixPath(name), path))
    for directory in SKILL_DIRS:
        folder = root / directory
        if not folder.is_dir():
            raise PackageError("skill package is missing required directory: {}".format(directory))
        for path in sorted(folder.rglob("*")):
            if not path.is_file():
                continue
            if path.is_symlink() or any(part == ".git" or part == "__pycache__" for part in path.parts):
                raise PackageError("refusing symlink or cache path in skill source: {}".format(path))
            relative = PurePosixPath(path.relative_to(root).as_posix())
            files.append((relative, path))
    for name in SKILL_RUNTIME_FILES:
        path = root / name
        if not path.is_file():
            raise PackageError("skill package is missing required file: {}".format(name))
        mode_path = PurePosixPath(name)
        files.append((mode_path, path))
    return files


def _scan_private(name: str, data: bytes) -> None:
    suffix = PurePosixPath(name).suffix.lower()
    if suffix not in TEXT_SUFFIXES:
        return
    text = data.decode("utf-8", errors="replace")
    if PRIVATE_PATH.search(text):
        raise PackageError("private home path leaked in {}".format(name))
    for pattern, label in PRIVATE_PATTERNS:
        if pattern.search(data):
            raise PackageError("{} leaked in {}".format(label, name))


def _write_zip(archive: Path, entries: Sequence[Tuple[PurePosixPath, bytes, int]]) -> None:
    archive.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for relative, data, mode in entries:
            info = zipfile.ZipInfo(relative.as_posix(), date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (mode & 0xFFFF) << 16
            bundle.writestr(info, data)


def _file_mode(relative: PurePosixPath) -> int:
    if relative.as_posix() == "scripts/package.py":
        return 0o755
    return 0o644


def build_skillhub_zip(output_dir: Optional[Path] = None, root: Optional[Path] = None) -> Path:
    base = (root or repository_root()).resolve()
    lock = load_lock(base)
    verify_vendored_dependency(base)
    entries: List[Tuple[PurePosixPath, bytes, int]] = []
    for relative, path in _skill_source_files(base):
        if path.is_symlink():
            raise PackageError("symlinks are not allowed: {}".format(relative))
        data = path.read_bytes()
        _scan_private(relative.as_posix(), data)
        entries.append((relative, data, _file_mode(relative)))
    dep = dependency_root(base)
    for path in sorted(dep.rglob("*")):
        if not path.is_file():
            continue
        if path.is_symlink():
            raise PackageError("symlinks are not allowed in vendored dependency: {}".format(path))
        relative = PurePosixPath("dependencies/agent-readiness") / PurePosixPath(path.relative_to(dep).as_posix())
        data = path.read_bytes()
        _scan_private(relative.as_posix(), data)
        entries.append((relative, data, 0o644))
    names = [item[0].as_posix() for item in entries]
    if len(names) != len(set(names)):
        raise PackageError("package would contain duplicate members")
    manifest = {
        "schema_version": "1.0.0",
        "target": "skillhub",
        "name": "brand-building",
        "version": __version__,
        "license": "MIT",
        "publication_status": "local_candidate",
        "files": [
            {"path": relative.as_posix(), "sha256": sha256_bytes(data), "mode": oct(mode)}
            for relative, data, mode in entries
        ],
    }
    manifest_data = (json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")
    entries.append((PurePosixPath("PACKAGE_MANIFEST.json"), manifest_data, 0o644))
    if len(entries) > SKILLHUB_MAX_FILES:
        raise PackageError("skillhub package exceeds {} files".format(SKILLHUB_MAX_FILES))
    output = output_dir or (base / "dist")
    archive = output / "brand-building-skillhub-{}.zip".format(__version__)
    _write_zip(archive, entries)
    validate_archive(archive, expected_lock=lock)
    return archive


def assemble_method_book(root: Optional[Path] = None) -> Path:
    """Generate a reading copy. Not a second authored source."""
    base = (root or repository_root()).resolve()
    verify_vendored_dependency(base)
    from .methods import BASELINE_METHOD_IDS, OWNED_METHOD_IDS, parse_method_items
    from .paths import baseline_method_path, owned_method_path

    baseline_text = baseline_method_path(base).read_text("utf-8")
    owned_text = owned_method_path(base).read_text("utf-8")
    baseline_items = parse_method_items(baseline_text)
    missing = [item_id for item_id in BASELINE_METHOD_IDS if item_id not in baseline_items]
    if missing:
        raise PackageError("pinned baseline is missing method IDs: {}".format(", ".join(missing)))
    extra = [item_id for item_id in baseline_items if item_id in OWNED_METHOD_IDS]
    if extra:
        raise PackageError("pinned baseline still contains owned method IDs: {}".format(", ".join(extra)))
    header = (
        "# Assembled whitehat method (generated)\n\n"
        "Generated reading copy. Baseline 26 IDs come from pinned agent-readiness. "
        "The additional 34 IDs come from this repository. Do not edit this file as source.\n\n"
    )
    output = base / ".generated" / "whitehat-method-assembled.md"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(header + baseline_text.rstrip() + "\n\n---\n\n" + owned_text, encoding="utf-8")
    return output


def _manifest_map(manifest: Dict[str, Any]) -> Dict[str, str]:
    listed = manifest.get("files") or []
    paths = [item.get("path") for item in listed]
    if len(paths) != len(set(paths)):
        raise PackageError("manifest contains duplicate paths")
    return {item["path"]: item["sha256"] for item in listed}


def validate_archive(path: Path, expected_lock: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    names: List[str] = []
    data_by_name: Dict[str, bytes] = {}
    for relative, data, _mode in iter_zip_files(path):
        name = relative.as_posix()
        names.append(name)
        if name in data_by_name:
            raise PackageError("archive contains duplicate members")
        data_by_name[name] = data
        _scan_private(name, data)
    if len(names) > SKILLHUB_MAX_FILES:
        raise PackageError("archive exceeds {} files".format(SKILLHUB_MAX_FILES))
    required = {"SKILL.md", "skill.yml", "LICENSE", "dependency-lock.json", "PACKAGE_MANIFEST.json"}
    missing = sorted(item for item in required if item not in data_by_name)
    if missing:
        raise PackageError("archive is missing: {}".format(", ".join(missing)))
    if "brand-brief.md" in data_by_name or "brand-work.md" in data_by_name:
        raise PackageError("owner project Markdown must stay private")
    manifest = json.loads(data_by_name["PACKAGE_MANIFEST.json"].decode("utf-8"))
    listed = _manifest_map(manifest)
    actual = {name: data for name, data in data_by_name.items() if name != "PACKAGE_MANIFEST.json"}
    if set(listed) != set(actual):
        raise PackageError("PACKAGE_MANIFEST coverage does not match archive members")
    for name, data in actual.items():
        if listed[name] != sha256_bytes(data):
            raise PackageError("PACKAGE_MANIFEST hash mismatch: {}".format(name))
    lock = json.loads(data_by_name["dependency-lock.json"].decode("utf-8"))
    dependency = lock.get("dependency") or {}
    commit = _require_commit(str(dependency.get("git_commit") or ""), "archive lock git_commit")
    digest = _require_sha256(str(dependency.get("skillhub_sha256") or ""), "archive lock skillhub_sha256")
    if expected_lock is not None:
        expected = expected_lock["dependency"]
        if commit != expected["git_commit"] or digest != expected["skillhub_sha256"]:
            raise PackageError("archive dependency-lock.json does not match the repository pin")
        if dependency.get("version") != expected["version"] or dependency.get("pin_kind") != expected["pin_kind"]:
            raise PackageError("archive dependency-lock.json does not match the repository pin")
    dep_prefix = "dependencies/agent-readiness/"
    dep_files = {
        name[len(dep_prefix):]: data
        for name, data in data_by_name.items()
        if name.startswith(dep_prefix)
    }
    if "SKILL.md" not in dep_files or "FILE_MANIFEST.json" not in dep_files or "PROVENANCE.json" not in dep_files:
        raise PackageError("archive is missing vendored agent-readiness manifests")
    provenance = json.loads(dep_files["PROVENANCE.json"].decode("utf-8"))
    file_manifest = json.loads(dep_files["FILE_MANIFEST.json"].decode("utf-8"))
    if provenance.get("git_commit") != commit or file_manifest.get("git_commit") != commit:
        raise PackageError("vendored provenance does not match archive lock commit")
    if provenance.get("source_archive_sha256") != digest or file_manifest.get("source_archive_sha256") != digest:
        raise PackageError("vendored provenance does not match archive lock hash")
    dep_listed = _manifest_map(file_manifest)
    dep_actual = {name: data for name, data in dep_files.items() if name != "FILE_MANIFEST.json"}
    if set(dep_listed) != set(dep_actual):
        raise PackageError("dependency FILE_MANIFEST coverage does not match archive members")
    for name, data in dep_actual.items():
        if dep_listed[name] != sha256_bytes(data):
            raise PackageError("dependency file hash mismatch: {}".format(name))
    body = data_by_name["SKILL.md"].decode("utf-8")
    if "license: MIT" not in body:
        raise PackageError("SKILL.md must declare MIT")
    if "publication_status: local_candidate" not in data_by_name["skill.yml"].decode("utf-8"):
        raise PackageError("skill.yml must remain a local candidate")
    return {
        "target": "skillhub",
        "path": str(path),
        "files": len(names),
        "sha256": sha256_file(path),
        "status": "pass",
    }
