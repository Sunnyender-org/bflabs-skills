# Changelog

## 0.1.1

- 不存在的地址必须返回 404。返回 200 且正文是别的页，记为缺口。
- 联系方式以可用渠道为准，不要求公开法律主体，并且不运行脚本也能读到。
- 出题单位改为意图组。已冻结的题按原题复测，新问法进入下一轮。
- 首页、文档、价格、政策和给 AI 的说明，要对照同一类事实。
- 激活优先用已有业务记录。不让代理为了补证据去付费调用。
- AI 回答分开判定提及、推荐、引用和事实。可以用主模型或分类模型，先做人工对照，不预设哪个更准。

## 0.1.0

- Standalone brand-building Skill repository with a versioned GitHub release.
- Owns brand plan/execute/resume, research, expression, distribution, the additional 34 method entries, and the T1–T10 teaching map.
- References the original 26 M1–M8 method IDs through a reviewed agent-readiness pin. Does not duplicate that baseline as authored source.
- Brand research works from the source checkout without installing the dependency. Website work reports a missing dependency instead of fetching latest.
- Ships fictional brand-project templates. Owner-filled project Markdown stays private.
- `publication_status` is `released`. `dependency-lock.json` pins commit, version `0.7.0`, and the skillhub SHA-256.

- Publish the versioned GitHub package and the Skills catalog download; keep third-party marketplace status separate.
