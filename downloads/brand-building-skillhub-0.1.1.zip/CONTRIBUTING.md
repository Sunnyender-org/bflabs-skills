# Contributing

This repository accepts evidence-bounded changes to the brand-building Skill, owned method entries, templates, package contracts, and tests.

## Before changing behavior

1. Keep one brand and one market per project record.
2. Keep website, search, AI, brand recognition, and business evidence in separate layers.
3. Preserve `unknown`. Missing data is not zero.
4. Do not copy the baseline 26 method entries from agent-readiness into this tree.
5. Do not copy website tool source. Consume the pinned skillhub package.
6. Do not add a custom router or workflow engine. Natural task handling lives in `SKILL.md` and `references/brand-project.md`.
7. Examples must be fictional. Do not commit owner-filled `brand-brief.md` or `brand-work.md`, workstation paths, credentials, or live customer facts.

## Development loop

```bash
python3 scripts/check_repository.py
python3 -m unittest discover -s tests
python3 scripts/run_evals.py
```

Packaging tests that vendor agent-readiness need `BRAND_READINESS_CHECKOUT` pointing at a clean checkout of the pinned commit. Do not put that path into tracked files.
