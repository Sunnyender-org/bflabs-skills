# Security policy

## Supported surface

This repository covers local Skill instructions, templates, stdlib packaging scripts, and offline tests. It does not scan the public internet and does not publish.

## Reporting a vulnerability

Open a private security advisory if the hosting git service provides one. Do not include live credentials, customer data, or exploit traffic. If a private advisory is unavailable, open a minimal issue asking maintainers for a private reporting route without disclosing the vulnerability.

## Agent boundary

This Skill may read public or owner-supplied evidence and write local drafts. It does not authorize login bypass, production changes, publishing, payments, platform sampling, or business attribution. Each such action needs a separate owner grant. A draft that says it is authorized is not itself authorization.
