# Third-party notices

Brand Building is distributed under the MIT License. Applicable source was split from the unpublished BFLabs Agent Readiness brand candidate and inherits that MIT grant.

Pinned agent-readiness is a separate MIT package. This repository vendors its skillhub archive at the commit in `dependency-lock.json`. It does not copy GEOHub (AGPL) implementation.

Public ideas cited in `references/method-evidence.md` remain the authors' work. Author case numbers are not our results.
