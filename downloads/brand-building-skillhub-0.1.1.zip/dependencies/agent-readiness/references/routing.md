# Routing

## Request classes

Classify every request as exactly one of:

1. **no-site** — there is no public URL yet, or the user only wants site-foundation / build-only work, including an explicit “just build the site, do not do brand positioning.” Select `seo-plan`. Do not invent a public URL. Do not start unrelated sampling. Do not open a round experiment. Do not open a brand project in this Skill.
2. **existing-site** — a real site or public URL is in scope. Pick the smallest matching capability, or an explicit GEO full round if that is what was asked.
3. **explain-only** — a definition or method explanation, including “how attribution works” with do-not-execute, “品牌建设是什么 / what is brand building”, and “只解释品牌定位 / just explain brand positioning” without an execute clause. Answer and stop. The router returns `needs_clarification`. Do not start a capability, workflow, round, or brand project.
4. **single-item** — one child Skill, one registered CLI workflow, or one offline analysis of a supplied export. Never escalate into a full round or a brand project. A page repair, title, or audit that also says “do not start brand construction” stays on the matching child Skill. Editing only the title on a brand-positioning page is `geo-content`, not a brand project. An audit of brand entity and public facts on a site is `geo-optimize`. Attribution-only analysis does not select `bflabs-agent-readiness`.
5. **full-round** — an explicit request to run the free GEO method end to end for one existing site, or to finish / judge whole-site coverage. Select `bflabs-agent-readiness` with GEO-round semantics. The two CLI workflows are not a full round. “整站做完整”, “整体完成了吗”, and “is the whole site done” belong here or in resume. They must not shrink to a single-page `geo-optimize` repair. They are not a brand project.
6. **resume** — an explicit request to continue an existing GEO project record, including asking whether the current site work is finished, or “continue our GEO round, not a brand-building project.” Select `bflabs-agent-readiness`. Start at `next_step`. Do not redo already-released actions. After a homepage-only verified action, “整体完成了吗” must surface uncovered clusters from the coverage ledger.
7. **brand-plan** — explicit brand construction, positioning, or strategy, including “do brand work but there is no website yet.” This Skill does not execute it. Return `needs_clarification` with reason code `brand-plan`. Do not select `bflabs-agent-readiness` as an installed brand provider. Do not shrink this to `seo-plan` just because there is no URL. Do not invent a public URL. Hand off to the separate brand-building repository: brand-building (separate Skill; resolve its installed entrypoint).
8. **brand-round** — an explicit complete brand-construction pass, including “run a full brand-building round end to end”, or a question about whether the brand project (not merely the site batch) is complete. Return `needs_clarification` with reason code `brand-round`. A published homepage is not brand-round completion, and this Skill does not judge brand-stage completion.
9. **brand-resume** — an explicit request to continue existing brand records, including reading `brand-brief.md` / `brand-work.md`. Return `needs_clarification` with reason code `brand-resume`. Do not rebuild those records here. Do not redo already-released site actions.

Older records remain readable. Do not fabricate identity, survey, refund, or business-window fields that the record does not contain. Do not fabricate brand-brief fields that a 0.6.6 GEO round never had.

## Unified Router Contract

Use `bflabs-readiness route --text` when a portable machine-readable decision is needed. The router applies this order:

1. reject forbidden guarantees, bulk publishing, hidden admin exposure, auth bypass, autonomous payments, paid rank-passing links, reciprocal first-place ranking, and fake reviews, unless that same span is locally negated or the request is risk-only discussion. A later unnegated buy-links clause still rejects; negation is not a whole-text waiver;
2. return `needs_clarification` for a bare ambiguous GEO/SEO/website ask;
3. return `needs_clarification` for explain-only, attribution-only, and do-not-execute requests so they cannot match a workflow, a full round, or a brand project;
4. honor one explicitly named capability;
5. recognize brand-resume or brand-round before a title-only page edit, then brand-plan before no-site, unless the request explicitly declines brand work. Those three classes hand off; they are not executable here;
6. select `seo-plan` for no-site / build-only / site-foundation requests that are not brand work;
7. recognize only the two explicit multi-stage requests below;
8. recognize an explicit GEO full-round or GEO resume request as root Skill guidance;
9. select the smallest matching capability for a single intent;
10. return `needs_clarification` when the request is ambiguous or outside this product.

Brand-plan, brand-round, and brand-resume are additive reason codes for a handoff. They do not add a seventh capability, a new provider, or a third workflow DAG, and they do not select this root Skill as an installed brand provider. Old GEO, audit, workflow, and no-site consumers still receive the same `kind`, selected id, and executable flag.

The only workflow definitions are:

- `discover-diagnose`: `geo-discover -> geo-optimize`;
- `discover-content`: `geo-discover -> geo-content`.

Both approved workflows are active and must run as one atomic workflow. They are not a full round and must not be advertised as one. Any planned capability is returned as non-executable with its nearest active fallback. Routing recognition is not permission to run an incomplete provider or cross an external gate.

## Route to `geo-discover`

Use `skills/geo-discover/SKILL.md` when the requested outcome is a traceable question or opportunity map across audience, scenario, comparison, decision, price/cost, integration, and limitation. Opportunity scoring may use only coverage gap, evidence gap, and declared business relevance; it must not invent search volume.

## Route to `geo-optimize`

Use `skills/geo-optimize/SKILL.md` when the requested outcome is repository-local:

- audit public facts, answer pages, schema, sitemap, robots, or `llms.txt`;
- repair volatile pricing or other machine-readable facts;
- check Agent Actionability without implementing WebMCP;
- verify approved GEO changes.

An audit of brand entity and public facts on a site is this capability, not a brand project.

## Route to `geo-content`

Use `skills/geo-content/SKILL.md` for one bounded evidence-linked content mode: title, explainer, comparison, ranking with disclosed method, page blueprint, refine, or article-friendly restructuring. Stale dynamic facts, unsupported claims, asymmetric comparisons, and rankings without method are blocked. Publication always remains owner-gated.

## Route to `geo-measure`

Use `skills/geo-measure/SKILL.md` only to aggregate user-supplied model-answer observations. It accepts JSON, JSONL, or CSV, preserves platform/terminal strata, reports numerator/denominator/excluded/missing counts and Wilson intervals, and excludes ordinary web search results. It does not perform platform sampling or infer causality and business outcomes.

## Route to `seo-plan`

Use `skills/seo-plan/SKILL.md` for migration, indexing, international, or technical SEO planning, and for site-foundation planning when there is no public URL yet and the user is not asking for brand construction. A no-site or build-only request selects this capability. It produces evidence gaps, prioritized read-only checks, captured official-source context, and owner-gated rollback-ready implementation actions. It does not invent a public URL, start unrelated AI sampling, access Search Console, mutate a CMS/server, or run live ranking queries.

## Route to `webmcp-enable`

Use `skills/webmcp-enable/SKILL.md` when the requested outcome includes:

- native WebMCP registration;
- connecting a same-origin MCP server to WebMCP;
- enabling Cloudflare WebMCP or a tool pack;
- compatible-browser or BrowserRun tool discovery and task calls;
- security review of browser Agent tools.

External enablement and production mutations are explicit-only. A local audit does not authorize them.

## Full round and resume

Route an explicit GEO full-round request, a whole-site completion question, or an explicit resume of an existing GEO round, to the root Skill's guidance. The selected capability is `bflabs-agent-readiness`. Follow `references/root-agent-contract.md` and `references/round-contract.md`. The one-site constraint applies to this GEO round.

Resume starts at the recorded `next_step`. It does not redo an action whose status is already `released` or `verified_public`, and it does not recapture a baseline that already exists for the same frozen questions. A verified homepage action is only that batch. It is not first-round construction and not the effect loop.

The two CLI workflows remain the only automatic multi-capability executions. A full round is not `discover-diagnose` and is not `discover-content`. Do not claim those workflows captured a baseline, released a change, retested public answers, compared AI answers, or reviewed business data.

Explain-only requests are answered without executing a capability or a workflow. A definitional prompt such as what GEO is, how attribution works, or a do-not-execute instruction must not start a round, a workflow, or a brand project.

A single-item request — including attribution on one supplied business export — is never escalated into a full round or a brand project.

## Brand plan, round, and resume

A full brand-construction request is recognized, then handed off. This Skill is not the installed active provider for brand-plan, brand-round, or brand-resume. The router returns `kind=needs_clarification`, `executable=false`, and the matching brand reason code. Optional `request_class` is emitted only for these new brand decisions.

Do not load moved brand-project files from this repository. The full lifecycle belongs to the separate brand-building repository: brand-building. Resolve its installed entrypoint; if unavailable, report the missing Skill. Do not invent an install URL.

Website-fact audits of brand entity, public pages, titles, and content stay here: an on-site brand-facts audit is `geo-optimize`; a title-only or bounded content request is `geo-content`. Optional `brand_context` on those child Skills is caller context, not brand-project orchestration.

Inherit already-granted authorization for website work already in scope. A declaration is not authorization. Pause only the unauthorized external action.

## Route to the diagnostic app

For a URL-only readiness check, first read `skills/geo-optimize/references/readiness-rules.md` (online: https://readiness.bflabs.cn/skills/geo-optimize/references/readiness-rules.md). These same judgment rules apply even without a repository or a repair request.

Use `app/readiness-web` only for bounded, read-only inspection of public fixed paths. Treat its score as an evidence index, not a ranking, business score, or brand score.

## Do not route here

- generic SEO, paid rank-passing links, reciprocal first-place ranking, fake reviews, or bulk content;
- real-platform ranking guarantees;
- hidden admin or permission mutation exposure;
- autonomous payment or credential handling;
- conversion or revenue attribution without customer-authorized data.

A white-hat request that plans transparent sponsorship and explicitly refuses paid rank-passing links, reciprocal first-place ranking, or fake reviews is not a forbidden request. Risk-only discussion of those tactics is not a forbidden request. If the same request later asks to buy rank-passing links, reject it.

Old GEO, audit, workflow, and no-site requests retain the 0.6.6 response shape, including omission of `request_class`. The optional field is emitted only for new brand handoff decisions.

For brand handoffs, `fallback.capability_id` is `brand-building`. This is an external Skill suggestion, never a readiness provider lookup. Resolve its installed SKILL.md and carry the current request and granted scope forward. If it is absent, say which Skill is missing; the owner does not need to restate the brand brief.
