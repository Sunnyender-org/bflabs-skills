# Brand context handoff

Optional `brand_context` on a content brief is a real input. The schema accepts it. The spec must keep it or keep a portable pointer such as `project:brand-brief.md`. Dropping the field, or claiming support in prose while the parser rejects it, is a defect.

This file is caller-context only. It does not own a brand project. Full brand-construction lifecycle belongs to brand-building (separate Skill; resolve its installed entrypoint). Do not load moved brand-project files from this repository.

## What the context may do

- Apply the canonical name, voice, and naming rules to the specification.
- Treat `forbidden_claims` as host-review constraints. A literal substring hit in facts or markdown is blocked; absence of a hit is not semantic proof.
- Point at the project brand brief so the next session does not invent a new voice. A local project path is allowed; public packages still need a portable locator.

## What it must not do

- Turn a positioning hypothesis into a product fact.
- Copy prices, limits, or other dynamic facts out of the expression brief. Those stay on `facts` with evidence ids, hashes, and `fact_version`.
- Bypass stale or unsupported fact gates.
- Treat an affiliated or sponsored source as independent evidence.
- Reject explicit rank exchange and fake independence. Disclosed first-party or affiliated self-ranking with a method is not automatically blocked.

## Disclosure, not regex

Record `source_disclosures`, `ranking_order`, and `link_practices` when those judgements matter. Do not scan the draft for phrases such as “禁止购买外链” and treat them as paid-link violations. If link acquisition cannot be judged, keep `link_practices.status=unknown` and say so. That is an auditable unknown, not a finding.

## Authorization and host boundary

`publication_gate` stays `owner-approval-required`. `publication_authorization` on the brief is a declaration, not proof. The host confirms the current session or owner grant and its scope before acting. A grant that is already confirmed may be reused without a ritual prompt. This capability does not publish. If there is no usable declaration, stop at a reviewable draft.

This Skill emits a specification and evidence-linked outline. It does not write a finished article, interview customers, or publish.
