# Source kinds

Keep the existing `source_kind` field. Do not invent a parallel taxonomy.

| `source_kind` | What it is | What it is not |
|---|---|---|
| `user_reported` | A real user or customer quote, with date and locator | Market share, search volume, or an invented persona |
| `support` | Sales or support notes in the original wording | A product advantage until a fact record confirms it |
| `onsite_search` | On-site search logs | Proof that the query has public demand |
| `platform_export` | An authorized query or Search export | Customer value, or a reason to invent volume |
| `public_community` | A verifiable public thread or post | An independent review if the author is affiliated |
| `agent_hypothesis` | A candidate the agent generated to test later | “Customers said”, observed demand, or search volume |

Every generated question keeps `provenance.source_kind`, `captured_at`, `market`, and `redacted`. Seed rows copy the supplied provenance. Template questions that are not in the seed list are `agent_hypothesis`.

If the brief has no user, support, or public-community quotes, emit candidates and research tasks. Do not write customer speech. Buying situations and alternatives stay `observed` only when they cite existing evidence_ids and their `source_kind` is not `agent_hypothesis`.

`source_inventory.counts` counts supplied seeds. Audience or scenario templates are generated even if the brief has a document-level provenance; they are not observed quotes.

This provider is a deterministic map. It does not interview customers and does not fetch live keyword data.
