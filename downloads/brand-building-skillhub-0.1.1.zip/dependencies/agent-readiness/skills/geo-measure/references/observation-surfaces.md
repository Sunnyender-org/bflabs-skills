# Observation surfaces

Keep these surfaces separate. Do not add them into the original AI answer denominators.

| Surface | `surface` / `source_kind` | Enters AI rates |
|---|---|---|
| AI answer | `ai-answer` / `model-answer` | Yes, after existing validity rules |
| Ordinary search result | `ordinary-serp` / `ordinary-web-search-result` | No |
| Featured snippet | `featured-snippet` | No |
| Google official display | `google-official-display` | No |
| Bing citation | `bing-citation` | No |
| Brand perception | `brand-perception` | No |

Official Google or Bing reports start as an authorized export. If the account was not read, mark `not_connected`. Do not fold those counts into AI visibility, ordinary Search impressions, or arrivals.

Human brand recognition is independent. A model mentioning the brand is not proof that people recognize it. If no authorized perception study exists, the status is `not_measured`.

Old inputs without `surface` stay valid: `model-answer` maps to `ai-answer`, and `ordinary-web-search-result` maps to `ordinary-serp`.
