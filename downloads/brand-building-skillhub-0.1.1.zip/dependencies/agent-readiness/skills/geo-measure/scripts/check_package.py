#!/usr/bin/env python3
"""Validate the public geo-measure Skill package."""

from __future__ import annotations

import csv
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
REQUIRED = ["SKILL.md", "agents/openai.yaml", "references/measurement-boundary.md", "references/sampling-guide.md", "references/observation-surfaces.md", "templates/measurement-input.json", "templates/observations.csv", "examples/measurement-input.json", "examples/round-pairing-input.json", "evals/trigger_cases.json"]


def fail(message: str) -> None:
    raise SystemExit("FAIL: " + message)


for relative in REQUIRED:
    if not (ROOT / relative).is_file():
        fail("missing " + relative)
skill = (ROOT / "SKILL.md").read_text("utf-8")
front = re.match(r"^---\n(.*?)\n---\n", skill, re.S)
if not front or "name: geo-measure" not in front.group(1) or "Not for" not in front.group(1):
    fail("invalid SKILL.md frontmatter")
for relative in ["references/measurement-boundary.md", "references/sampling-guide.md", "references/observation-surfaces.md", "templates/measurement-input.json", "templates/observations.csv"]:
    if relative not in skill:
        fail("SKILL.md does not route to " + relative)
for relative in ["templates/measurement-input.json", "examples/measurement-input.json", "examples/round-pairing-input.json", "evals/trigger_cases.json"]:
    json.loads((ROOT / relative).read_text("utf-8"))
with (ROOT / "templates/observations.csv").open("r", encoding="utf-8", newline="") as handle:
    if not list(csv.DictReader(handle)):
        fail("CSV template needs one example row")
cases = json.loads((ROOT / "evals/trigger_cases.json").read_text("utf-8"))["cases"]
positive = sum(case["should_trigger"] is True for case in cases)
negative = sum(case["should_trigger"] is False for case in cases)
if positive < 8 or negative < 8:
    fail("trigger evals need eight positive and eight negative cases")
for path in ROOT.rglob("*"):
    if not path.is_file() or path.suffix not in {".md", ".json", ".yaml", ".yml", ".py", ".csv"}:
        continue
    content = path.read_text("utf-8")
    mac_user_prefix = "/" + "Users/"
    windows_user_prefix = "C:" + "\\Users\\"
    if mac_user_prefix in content or windows_user_prefix in content:
        fail("private absolute path leaked in " + str(path.relative_to(ROOT)))
print("PASS: geo-measure package ({} positive routes, {} negative routes)".format(positive, negative))
