# Brand-task page changes

This Skill may change an approved public page that states brand facts. Readiness scores do not replace customer research or positioning. Full brand-construction lifecycle belongs to brand-building (separate Skill; resolve its installed entrypoint).

- Use the project fact record. Expression rules may constrain wording; they do not create prices, limits, or testimonials.
- Prefer the current URL. Several questions may share one page.
- A blueprint from geo-content is pending implementation until the host edits the site and reads the public URL back.
- If publication authorization is already recorded, inherit it and do not ask again. A declaration is not authorization. If it is missing, stop at a local draft.

Do not treat a passing local scan as a released page, an AI-visibility gain, or a business result.
