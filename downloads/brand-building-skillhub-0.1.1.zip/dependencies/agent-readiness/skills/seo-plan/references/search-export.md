# Authorized search exports

Search Console or Bing exports are optional. Missing access does not block a technical plan. Do not invent query volume. Do not treat zero impressions as a sufficient reason to create a new page.

When an authorized export is present, record the source, market, window, and each query with the current page if one exists. Then review:

1. Search intent and the job the current page already does.
2. Whether the needed facts are missing, stale, or on another URL.
3. Indexing or discovery issues on that URL.
4. Whether several queries can share one page.

Do not analyze queries when the export is missing or `not_authorized`. An authorized export still needs source, market, window, and evidence ids that exist on the brief; missing metadata is a gap, not a page decision.

Zero impressions is one signal. An index issue is also only one signal. `consider_new_page` requires an intent gap or a content gap—not an empty impression cell and not an index failure alone.

Keyword overlap is not proof of cannibalization. Keep this Skill read-only: no console login, no CMS mutation, no ranking query.
