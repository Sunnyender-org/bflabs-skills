# 所有权与文档迁移

本仓库从 agent-readiness 的未发布品牌候选中拆出，成为独立根仓库。网站能力不搬进本源码树。

## 现在由 brand-building 持有

- 根 Skill `brand-building` 与其触发说明
- `references/brand-project.md`：计划、执行、续跑、阶段完成
- `references/brand-research.md`：客户证据、购买情境、替代方案、定位
- `references/brand-expression.md`：名称关系、识别资产、语气、主张证据
- `references/distribution-and-trust.md`：渠道、站外资产、披露、纠错、链接判断
- 新增 34 条方法条目（M1–M8 内新增条目 + M9–M13），见 `references/whitehat-method.md`
- T1–T10 教学地图，见 `references/method-map.json`
- `templates/brand-brief.md`、`templates/brand-work.md` 与虚构示例
- 方法证据记录里与上述条目有关的外部观点、假设和反例修订

填好的 `brand-brief.md` 和 `brand-work.md` 属于主人的项目目录，保持私有。

方法复核表仍由 agent-readiness 持有：安装依赖后读 `dependencies/agent-readiness/templates/method-review.md`。本仓库不复制一份通用复核表。

## 仍由 agent-readiness 持有

- 网站诊断、六个子 Skill、两条 CLI 工作流
- 原 M1–M8 基线 26 条方法
- 网站基础、单站 round、到站来源问卷、业务归因实现
- geo-content 的内容合同与品牌交接
- `templates/method-review.md`

本仓库通过 `dependency-lock.json` 钉住一次已审 git 提交、版本和 skillhub SHA-256，用其 skillhub 包生成 `dependencies/agent-readiness/`。禁止复制网站工具源码，禁止循环依赖，禁止安装时解析为 latest。

## 文档怎么读

源码检出：

- 使用者：本仓库 `README.md` 和 `SKILL.md`
- 品牌编排：`references/brand-project.md`

安装 zip 之后：

- 网站诊断：`dependencies/agent-readiness/SKILL.md`
- 写页面正文：`dependencies/agent-readiness/skills/geo-content/references/content-contract.md` 与 `dependencies/agent-readiness/skills/geo-content/references/brand-handoff.md`
