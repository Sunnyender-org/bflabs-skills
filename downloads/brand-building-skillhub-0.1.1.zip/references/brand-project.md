# Brand project

Agent-only orchestration for one brand in one market. Use the user's review language for explanations; public content follows the project's target language.

## Duty

编排一个品牌在一个市场里的计划、执行、续跑和阶段完成。这里决定读哪些模块、留下哪两份记录、怎样引用单站 round。不在这里做客户访谈分析细则、不写视觉规范、不登记站外信源表。

Overlapping principles live in `references/whitehat-method.md` as M9. Read `references/brand-research.md`, `references/brand-expression.md`, or `references/distribution-and-trust.md` only when the current gap needs them.

## When to load this file

Load when the request is brand construction, brand resume, or judging whether a brand stage is complete.

Do not load, and do not open a brand project, for:

- URL 审计、只改一个 title、只解释 AEO/GEO/SEO
- 已有单站 GEO round 的续跑，且用户没有改口要做品牌项目
- 只要建网站，且没有提出定位、识别或站外品牌工作
- 一份搜索导出或业务导出的只读分析

“做品牌，但还没有网站”先进入研究。只有明确“先给我建个网站”才走网站基础方案。没有 pinned agent-readiness 依赖时，报告缺口并给出安装动作，不要虚构公开地址；品牌研究继续。

## One brand, one market

一份品牌项目 = 一个品牌名 + 一个市场（国家/语言/买方任务）。第二品牌或第二市场新建项目，不互借事实、价格、客户原话或基线。

多触点可以存在：官网、文档站、状态页、社区账号。它们写在简报的入口角色表里。每一个需要测量的网站，仍使用原来的单站 round 记录，见 `dependencies/agent-readiness/references/round-record.md`（安装依赖后）。品牌项目引用 round，不把两个站点装进同一个 `experiment.json`。

## Minimum records

第一版只有两个可读载体，从模板复制后放进主人指定的项目目录：

| 载体 | 模板 | 写什么 | 不写什么 |
| --- | --- | --- | --- |
| 品牌简报 | `templates/brand-brief.md` | 品牌与市场、客户与替代方案、主张指针、关系、表达规范、假设、主人确认 | 价格全文、发布状态、站外日历 |
| 工作记录 | `templates/brand-work.md` | 阶段、成果、授权、下一步、依赖、验收指针、站外资产与反馈 | 第二份动态事实、到站问卷答案 |

动态事实引用已有的权威产品来源；若没有网站或单站 round，可使用项目内独立事实文件，不创建 experiment，也不发明 URL。已有 round 时沿用其事实记录。简报只保存指针，例如“价格见 facts.json 的 `price_monthly`”。网站动作状态只写 action id 或 coverage 行指针，不手工复写 `released` / `verified_public`。

pinned agent-readiness `templates/source-survey.md`（安装依赖后：`dependencies/agent-readiness/templates/source-survey.md`） 仍是给已经到站、并且愿意回答的人用的来源问卷。不要拿它登记外链、客座文章或媒体名单。

不要先造品牌数据库、CRM 或统一总分。能靠这两份 Markdown 和已有 round 文件解决的，就不要新增账本。

## Plan, execute, resume, complete

### 计划

1. 写死品牌、市场、本阶段范围和明确不做。
2. 盘点已有公开页、已有 round、已有授权。没有就写没有。
3. 按缺口选择模块，不要把 T1–T10 整包列为必做。
4. 列出主人必须确认的事项，以及现在就能做的研究或草稿。

计划阶段可以没有网站。输出是带假设的简报草案和工作记录里的下一步。

### 执行

只做当前缺口。常见顺序，可跳过已完成项：

1. 客户证据与定位草案（`references/brand-research.md`）
2. 关系与表达规范（`references/brand-expression.md`）
3. 如需要网站：先按 M2/M3/M5 做页面与事实交接；只有明确要求 AI 前后实验且有真实网站时，才引用或新开单站 round。普通建站不自动开启实验或采样
4. 如需要发现：查询与页面映射、技术缺口，无搜索账户也能继续内容研究
5. 一份可核验核心资产，再改编到需要的触点。起草产品正文或内容规格前，读取 `dependencies/agent-readiness/skills/geo-content/SKILL.md`、`dependencies/agent-readiness/skills/geo-content/references/content-contract.md` 和 `dependencies/agent-readiness/skills/geo-content/references/brand-handoff.md`。按其事实、比较、披露规则执行，不另造写作流程。没有依赖时，停止网站正文起草并报告缺口。没有可用校验程序时由宿主按相同证据规则写草稿，不得写成校验已通过。
6. 一个主要站外渠道的授权贡献（`references/distribution-and-trust.md`）
7. 分层观察：认知、网站、搜索、直接答案、生成答案、业务，能测哪层写哪层。AI 回答分开判定提及、推荐、官网引用和事实对错。判定可以用主模型，也可以用分类模型；先用同一批人工标注对照，再决定用哪一个。没有对照，不说某个判定器更准。原始回答全部保留

宿主负责真实执行和权限。本文件给出流程和验收，不代替发帖、部署或付款。

### 续跑

1. 先读工作记录的当前阶段和下一步，再读简报。
2. 已有明确授权的动作直接继续，不要仪式性再问一次。
3. 不要重做已经发布并读回的网站动作。
4. 旧 round 没有品牌简报仍然可读；不要补造历史品牌字段。
5. 缺某一类权限或数据时，暂停该类动作，推进其他已有证据允许的工作。

### 阶段完成

对照工作记录里本阶段范围逐项判断。全部约定项已执行、结果真实、未做项可见、下一步有依据，才写“本阶段完成”。

不能宣布品牌整轮完成的情况：

- 网站批次已验证，但约定的研究或站外任务还没做
- 准备度分数看起来高，但定位仍是未确认假设
- 没有业务数据却把获客闭环写成完成
- 效果未测，却用建设进度代替效果

建设验收和效果判断始终分开。见 M9-stage-completion 与 M13-metric-layers。

## Owner confirmations and hypotheses

简报必须分开两栏：

- 需要主人确认：定位句子、品牌关系、不能公开的主张、真实发布、外联、费用
- 未验证假设：来源、怎样证实、怎样推翻、当前状态

Agent 不替主人确认品牌架构，不把假设升级成“客户说”。研究受访者的感受保留为主观原话。

## Authorization

读取公开资料、整理已有材料、写方案和草稿：直接做。

访谈邀请、客户消息、社区发帖、公开发布、生产部署、实际付款、分析账户接入：沿用本会话或该项目已记录的授权。缺授权只暂停该动作。

未授权发布停在可审草稿。已有明确授权不再索要许可。

## Host and free method

免费方法完整。用户自带 Agent、权限和数据。不要把连接器、课程或付费宿主写成开工前提。实际搭页、改仓库、发帖和部署归宿主 Agent。交接时写清要做什么、依据哪条事实、谁来发布、怎样读回、哪些未做。

## What this project must never do

- 自动裁定母子品牌或“旗下”
- 互排第一、伪评、注入、刷点击、买传权链
- 把所有模板页或相关互链判违规
- 用新用户问法覆盖旧题和旧基线
- 把品牌心智、网站准备度、搜索、AI、业务加成总分
- 把私人路径、内部工单或真实客户身份写入公共包或公共案例。私有项目可以在授权范围内引用必要的材料，使用最小必要信息，分发前脱敏

## Resume checklist

打开项目目录后按这个顺序读：

1. `brand-work.md`：阶段、授权、下一步
2. `brand-brief.md`：假设和未确认项
3. 简报里指向的事实记录，而不是简报里的复述
4. 工作记录里指向的 round 状态，而不是手工摘要
5. 只加载当前下一步需要的参考
