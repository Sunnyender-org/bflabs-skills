# Method evidence

Agent-only. Teaching, Skills, and reports may quote the Chinese sentences. This file does not store product prices, models, or customer facts.

A method claim can be one of three records. Keep them separate. Do not promote one kind into another because the wording is confident.

## Three record kinds

### 1. External view

别人怎么说。官方文档、作者方法、厂商文章或转述案例都属于这一类。

Write down: who said it, when, where, the claim in their words, what we adopt, and what we refuse to copy.

作者的案例不是我们的成效。厂商文章里的流量、合同金额或满意度，不能写成我们的结果，也不能变成字数或收费指标。

Example that must stay an external view:

- 姚金刚 2026-09-11 提到某服务商整理知识库后，内容和合同都让客户满意。这是作者转述，没有我们核过的客户、合同或测量。可采用的方向是先理清企业事实，再写对真人也有用的内容。不得把字数或合同金额当成方法验收。

### 2. Project hypothesis

我们准备这样试，但还没有被本项目的证据证实或反驳。

Write down: the hypothesis, why it is needed now, what would support it, what would refute it, and the current maturity (`project_hypothesis`).

一次看起来变好，不能自动升级成熟度。

Example that must stay a project hypothesis until measured:

- 首轮网站工作仍可从首页、一张产品或价格页、一张接入说明开始。这不是已证明的最佳页数。没有网站时，品牌研究可以先做。

### 3. Counterexample revision

实践、核对或反例说明：原来的说法不成立，或适用条件必须收窄。

Write down: what we used to believe, what we saw, which source changed, which method changed, and how the old sentence is preserved. Use maturity `revised` only on the method entry that actually changed.

来源变化和方法变化要分开记。不能把旧记录改写成“当时就知道”。

Example of a revision that is not a customer result:

- 曾有执行稿假设：答案页不进人类导航，落地本身更能证明 AI 来源。核对后的方法是：页面服务正常读者；可以放在文档或帮助中心，不必挤进顶部菜单；公开地址仍可能从搜索、转发或书签进入；缺来源保持未知。这是对未采用假设的修订，不是某个站点已经获客。

## Practice may refute a method

When later evidence conflicts with a method step:

1. Keep the original method sentence and its date.
2. Add a review using `dependencies/agent-readiness/templates/method-review.md` after the dependency is installed.
3. Record the source change if the cited document moved, disappeared, or was corrected.
4. Record the method change if the principle, condition, or action is now different.
5. Point `references/method-map.json` at the same method ID. Do not silently edit old case records to match the new rule.

工具故障就修工具，并留下能复现的反例。方法不适用就改适用条件或撤回结论，不要为了保住方法而换样本。数据缺失就补可观察环节，不能把未知写成无效，也不能估成收入。

## What each kind may support

| Kind | May support | Must not become |
| --- | --- | --- |
| external view | wording, caution, a cited official rule | our traffic, our revenue, our case study |
| project hypothesis | this project's next action and its untested boundary | platform_docs, case_observation, or a guarantee |
| counterexample revision | a narrower condition or a withdrawn step | a claim that the old case already used the new rule |

Small sites may stop at a descriptive case. Do not invent a causal score to make the record look complete.

## 2026-09-16 brand-method records

These records support the M9–M13 additions and the T1–T10 teaching order. They do not rewrite older GEO-round evidence. Do not copy private paths, customer exports, or restricted third-party manuals into this file.

### External views adopted as method wording

Write-up date: 2026-09-16. Maturity of the cited method entries stays in `references/whitehat-method.md`. Author growth numbers stay outside our results.

- R01 April Dunford, [定位入门](https://www.aprildunford.com/post/a-quickstart-guide-to-positioning), 2021-03-15. Adopt the order: actual alternatives, then provable difference, then value, then best-fit customer, then category. Refuse slogan-first worksheets and any claim that filling a form proves positioning.
- R02 Ehrenberg-Bass, [B2B 品类进入情境](https://marketingscience.info/news-and-insights/category-entry-points-in-a-business-to-business-b2b-world), read 2026-09-16. Adopt buying situations as an interview and topic dimension. Refuse treating a handful of talks as mental-availability share, and refuse swapping human memory for model mention rate.
- R03 Ehrenberg-Bass, [品牌识别资产](https://marketingscience.info/learn-with-us/commercial-research/distinctive-asset), read 2026-09-16. Adopt name, mark, and language as assets that need recognition and uniqueness evidence. Refuse “we like the palette” as distinctiveness.
- R04 Ahrefs, [Product-led content](https://ahrefs.com/blog/product-led-content/), 2022-05-03. Adopt real product steps that finish a reader task. Refuse copying the vendor’s traffic story as our forecast.
- R05 HubSpot, [主题、支柱页与子主题](https://knowledge.hubspot.com/content-strategy/pillar-pages-topics-and-subtopics), 2025-11-20. Adopt related questions and pages as a map. Refuse fixed article counts, mandatory long pillar pages, and “the tool cluster itself improves SEO”.
- R06 Linear, [Brand Guidelines](https://linear.app/brand), read 2026-09-16. Adopt a short, enforceable name and mark spec that can guide more than one touchpoint. Refuse copying Linear’s visual style or treating the public guide as growth proof.
- R07 Stripe, [Get started](https://docs.stripe.com/get-started), read 2026-09-16. Adopt a path from explanation to a first successful action. Refuse treating docs existence as completed onboarding.
- R08 Google, [生成式搜索优化指南](https://developers.google.com/search/docs/fundamentals/ai-optimization-guide), page updated 2026-07-10. Adopt useful original content, crawlable pages, and no AI-only variant farms. Refuse extra Schema or `llms.txt` as a Google citation switch. Google’s rules are not every AI platform’s rules.
- R09 Google, [精选摘要](https://developers.google.com/search/docs/appearance/featured-snippets), updated 2025-12-10. Adopt direct-answer results as their own observation. Refuse a guaranteed word count, format, or Schema for inclusion.
- R10 Google, [垃圾政策](https://developers.google.com/search/docs/essentials/spam-policies), read 2026-09-16. Adopt refusals for bought PageRank, fake reviews, scaled thin pages, and hidden manipulation. Refuse expanding that into “every template page, footer link, or related internal link is spam”.
- R11 Google, [Generative AI performance report](https://support.google.com/webmasters/answer/16984139?hl=en), including 2026-08-31 notes. Adopt official generative impressions as their own row. Refuse stuffing them into an AI-answer aggregator denominator or treating them as orders. Account availability stays field-checked.
- R12 Bing, [AI Performance](https://blogs.bing.com/webmaster/February-2026/Introducing-AI-Performance-in-Bing-Webmaster-Tools-Public-Preview), 2026-02-10. Adopt citation counts and sampled queries as Bing-only evidence. Refuse using them as rank-in-answer or revenue proof. Fine-grained robots claims that were only second-hand are not recorded as rules here.
- R13 GEO paper, [arxiv.org/abs/2311.09735](https://arxiv.org/abs/2311.09735), 2023. Adopt the idea that generative visibility can be studied with named engines and metrics. Refuse the paper’s percentages as customer promises or a production playbook.
- R14 Yao Jingang, analysis-completeness note dated 2026-05-16, read from the public main file on 2026-09-16. Adopt the completeness check: business, questions, facts, content, sources, and monitoring. Refuse copying that repository’s implementation, and refuse treating completeness as proven tactic effect.
- R15 PostHog, [AEO 实践复盘](https://newsletter.posthog.com/p/llms-are-picking-winners-heres-how), 2026-06-08. Adopt asking the original prompt only after a person says they first learned via AI; keep synthetic monitor prompts separate from real user questions. Refuse the vendor growth multiples, and refuse rewriting an old frozen set to chase a prettier score.
- R16 PostHog, [SEO 写作手册](https://posthog.com/handbook/content/seo-guide), read 2026-09-16. Adopt intent, a direct answer, updates, and fair competitor presentation as editorial practice. Refuse turning their internal link counts or ranking folklore into platform law.
- R17 Ahrefs, [自家 AI 引荐落地页](https://ahrefs.com/blog/ai-search-traffic-by-page-type-ahrefs/), 2025-06-16. Adopt the reminder that tools, product pages, and the homepage can carry demand, not only blogs. Refuse copying that site’s page-type mix as our required mix.
- R18 Ahrefs, [品牌相关性研究](https://ahrefs.com/blog/ai-overview-brand-correlation/), 2025-05-26. Adopt mentions, brand search, and citations as observation dimensions. The source itself says correlation is not causation. Refuse buying mentions or setting a quota of posts that “must” produce recommendations.
- R19 Stripe, [网站清单](https://docs.stripe.com/get-started/checklist/website), read 2026-09-16. Adopt product, price/currency, contact, and refund or fulfilment copy as conversion trust. Refuse treating it as worldwide legal advice or an AI citation condition.

### Project hypotheses

- Two Markdown carriers (`templates/brand-brief.md` and `templates/brand-work.md`) are enough to resume a brand project before any brand database exists. Support: a later session can find stage, next step, hypotheses, and owner confirmations. Refute: resume repeatedly fails because durable facts have nowhere to live. Current maturity: `project_hypothesis`.
- First-round site work may still start from home, one product or price page, and one getting-started page. That remains a project hypothesis, not a proven page count. Brand research can start with no site at all.
- A short expression spec can guide a website and one off-site draft without a full design system. Support: two touchpoints use the same names and claims. Refute: hosts still invent a third public name after the spec exists.

### Counterexample revisions

These correct earlier research suggestions. Keep the rejected sentences visible.

- Former suggestion: extend existing GEO modules with a few extra paragraphs and skip a brand project record. Seen: without a brief and a work log, “brand work with no site” and off-site execution have no resume owner. Method change: keep M1–M8 IDs; add M9–M13 and the two Markdown carriers. Old GEO rounds remain valid without a brief.
- Former suggestion: reuse `templates/source-survey.md` as the off-site source table. Seen: that file is an arrival questionnaire for people who already reached the site. Method change: off-site assets live in the brand work record. The survey file keeps its original duty.
- Former suggestion: consider a new URL only when a query has no impressions. Seen: impressions are one signal beside intent, content gap, index state, and current page purpose. Method change: `M3-page-intent`. Missing Search Console data does not halt research and does not force new pages.
- Former suggestion: treat template pages, footer links, or related internal links as violations by default. Seen: spam policy targets manipulation, scaled thin pages, and deception. Method change: `M12-link-judgment`. Judge purpose, usefulness, scale, and disclosure.
- Former suggestion: obtain third-party reviews before practice starts. Seen: first-party facts and real public artefacts can ship first. Method change: keep `M5-citation-sources`; third-party gaps remain gaps.
- Former suggestion: replace old questions when real user phrasing looks more useful. Seen: that destroys comparability and hides failure. Method change: `M4-question-generations`. Old rounds stay; new phrasing gets a new version and baseline.
- Former suggestion: fold official Google or Bing generative reports into the existing AI-answer denominator. Seen: those reports are different objects with different availability. Method change: `M6-surface-separation`. Unconnected accounts stay unconnected, not zero.
- Former suggestion: confirm brand architecture before any other work. Seen: unconfirmed relations should only pause statements that depend on the relation. Method change: `M11-brand-relations`.

## Related contracts

- Method prose: `references/whitehat-method.md`
- Pointers: `references/method-map.json`
- Brand project: `references/brand-project.md`
- Review form: `dependencies/agent-readiness/templates/method-review.md`
