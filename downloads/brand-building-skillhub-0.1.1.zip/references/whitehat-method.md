# 白帽品牌建设方法

Agent-only method source. Teaching, Skills, and reports use the same words. Use the user's review language for explanations; public content follows the project's target language. Method IDs and maturity values stay exact.

工作名：从定位与网站到搜索、AI 和业务验证。这是理论工作名，不是产品改名。

This file is the public method owned by brand-building. It contains only the additional 34 method entries: new items inside M1–M8 plus M9–M13. The original M1–M8 baseline of 26 IDs lives in the pinned agent-readiness checkout at `references/whitehat-method.md`. After `scripts/package.py vendor`, read `dependencies/agent-readiness/references/whitehat-method.md`. Do not copy those 26 entries into this file.

Product prices, models, and customer facts live only in each project's fact record. Do not keep editable copies here. Brand-project examples must be fictional.

Teaching order T1–T10 lives in `references/method-map.json`; it does not replace these IDs and is not a required runtime set. Load only the items the current task needs.

Brand research, positioning, and expression can proceed from this file without installing the agent-readiness dependency. Website diagnosis, site-foundation, GEO rounds, and geo-content drafting require that dependency.

## Shared vocabulary

Brand-project examples must be fictional. Do not copy live customer or product facts into this file.

Keep these five ideas separate. They can describe the same person and the same order. They must not be added together, and they must not be renamed as increment.

| Term | 中文 | Meaning | Business example | Must not infer |
| --- | --- | --- | --- | --- |
| discovery channel | 发现渠道 | How the person first learned the product exists | 用户自报：最早在一篇教程里知道这个接口服务 | 不能把这次浏览器来源改写成第一次发现 |
| arrival channel | 到站渠道 | How this visit reached the site | 这次访问的来源是 Google | `google.com` 是搜索到站，不是 AI |
| page touch | 页面接触 | Which public page was opened | 打开了接入说明页 | 打开某页不能证明来自某次 AI 回答 |
| paid | 实付 | Money that actually cleared, after status and refunds | 一笔已支付订单 | 待付、失败、测试、充值余额不是确认收入 |
| increment | 增量 | Extra outcome caused by a defined change | 尚未具备对照时，只写观察，不写增量 | 有来源的实付不是优化带来的新增收入 |

Also keep four GEO-round result layers separate:

- 网站准备度：人能不能找到信息并做下一步，AI 能不能读到同一批事实。
- 真实 AI 表现：真实平台有没有提到、引用或推荐。
- 已观察业务结果：授权记录里实际发生的到访、注册、调用和实付。
- 优化增量：只有合适对照时才能谈；完成一轮工作本身是可交付结果。

Brand work adds independent evidence layers. They describe the same brand. They must not be summed into a score:

- 品牌定位与认知：明确人群是否认识、识别，并在相应需求情境考虑这个品牌。
- 内容与网站：页面是否完整、事实是否准确、真实任务能否完成。
- 普通搜索：授权搜索数据里的查询、页面、品牌/非品牌、国家与设备。
- 直接答案：具体问题是否得到清楚、完整、条件准确的答案，以及直接答案结果。
- 生成答案：生成回答是否检索、理解、引用或推荐品牌及其事实。联网回答、训练记忆、用户主动给 URL 不能混算。
- 分发与声誉：经授权的真实发表、相关讨论、独立来源、反馈和纠错。
- 业务：有效访问、注册、项目定义的激活、留存、付款与退款。

没有客人从看到走到付钱，不能说获客已经走通。没有成交，也不等于方法没用。人的品牌认知和模型是否提及品牌是不同对象。

操作定义：

- **品牌建设**：让明确的人群认识、识别、信任并在相应需求情境考虑这个品牌，且产品体验支持承诺。
- **SEO**：改善搜索发现与访问的条件，包括技术、内容、信息结构及可信外部信号。
- **AEO**：本方法中指使具体问题得到清楚、完整、条件准确的答案，并观察直接答案结果。不是全行业统一术语，不是额外 Schema。
- **GEO**：观察并改善生成回答检索、理解、引用和推荐品牌及其事实的条件。

不新造四条内容流水线。一份可靠的接入说明可以同时服务用户、搜索和生成式回答，但各入口结果分别验证。

## Positive whitehat

只写真实产品、真实经验和能核对的数据。页面给真人阅读、给真人继续办事，并用相关页之间的正常链接连起来。来源和日期按实际变更写。

正向做法：真实研究与产品使用、准确描述、清楚比较、可复现示例、相关内链、透明作者关系、合法公开资料维护、真实客户授权案例、对社区有用的贡献、可核验纠错。

不要求把页面藏进导航。不编口碑、评价或权威。不为了显得新而改日期。一份合法说明不在顶部菜单里，只要人能从页脚或相关页到达，就不算缺陷。相关页之间的正常链接、页脚政策入口、有真实用途的模板页，不自动判违规。

拒绝：购买传权链接、交换第一名、伪装独立评测、批量假账号或假评价、组织刷点击、隐藏给模型的操纵指令、伪造权威或客户标志、批量同质地域页、为年份新鲜感刷日期、夸大性能与收入。

透明赞助和付费广告可以有合法价值，但不以买排名为目标。本方法不代买、不自动外联。关系相关性、披露、链接属性和受众价值分别核对。白帽也不意味着拒绝商业内容或任何自动化。

公开地址仍可能从搜索、转发或书签进来。缺来源时保持未知，不要补成 AI。第三方评价不是开工前提；有可核对的第一方事实和公开产物时可以先做，第三方缺口继续保留。

## Maturity

Use exactly one of: `platform_docs` | `general_method` | `project_hypothesis` | `case_observation` | `multi_case_review` | `revised`.

Do not raise maturity because one case looked good. A later practice may refute a step; record that in `references/method-evidence.md` and, after vendor, `dependencies/agent-readiness/templates/method-review.md`.

---

## M1 目标与白帽原则

Baseline IDs (pinned agent-readiness, not duplicated here): `M1-purpose`, `M1-whitehat`, `M1-stage-metrics`.

### M1-seo-aeo-geo


- **question**: 这一轮里的 SEO、直接答案和生成答案各回答什么，能不能合成一套分数？
- **principle**: SEO、AEO、GEO 是有重叠的操作分类，不是三套独立算法，也不是三个产品。Google 把自家生成式搜索工作视为 SEO。本方法用 AEO 表示直接答案的表达与结果观察，用 GEO 表示生成回答中的检索、事实吸收、引用和推荐。一份内容可以同时服务这三类入口，观测必须分行。
- **applicable_when**: 写项目目标、解释术语、设计测量或有人要求“做一套 AEO/GEO 系统”时。
- **actions**: 在项目目标里写清要改善的是发现、直接答案、生成答案还是业务关系。需要测量时，为普通搜索、精选摘要或直接答案、生成回答各留独立证据行。不要新增专用 AI Schema 或机器专用正文来“解锁引用”。
- **counterexample**: 把 SEO、AEO、GEO 拆成三套内容流水线；或把 Google AI 展示、Bing 引用和 ChatGPT 提及加成“全网影响力”。
- **acceptance_evidence**: 术语有操作定义；三类发现证据没有共用一个分母；没有把 llms.txt 或 FAQ 形状写成引用保证。
- **sources**: [Google 生成式搜索优化指南](https://developers.google.com/search/docs/fundamentals/ai-optimization-guide)；[Google 精选摘要](https://developers.google.com/search/docs/appearance/featured-snippets)；[GEO 原始研究](https://arxiv.org/abs/2311.09735)
- **maturity**: `general_method`

---

## M2 网站基础与承接

## M2 网站基础与承接

Baseline IDs (pinned agent-readiness, not duplicated here): `M2-site-foundation`, `M2-information-architecture`, `M2-action-entry`.

### M2-user-path


- **question**: 一个合适的人从了解、比较、试用到第一次得到价值，现在走得通吗？
- **principle**: 网站按真实任务组织，不按内部部门或关键词清单组织。开发者工具和专业服务常见路径是：这是什么、和现有办法比如何、怎样试用、怎样第一次成功。文档、价格、政策、支持必须互相一致。内容资产不限于博客：工具、产品页、首页、文档都可能承接任务。
- **applicable_when**: 规划或验收首页、产品、文档、价格和政策页时；或品牌项目第一次落到网站时。
- **actions**: 写出本市场的一条主路径，标出每一步的页面、所需事实和下一步。用真实产品步骤检查试用和首次价值，不要只读标题。缺页时优先补能完成任务的页，不先批量写博客。不存在的地址必须返回 404，并标记不被索引；返回 200 且正文是首页或其他页的，记为缺口。登录、控制台等真实路由保持原有状态。路径走不通就记缺口；无网站时按 `dependencies/agent-readiness/references/site-foundation.md` (after vendor; required only for website work) 交最小页面清单。
- **counterexample**: 只有品牌故事没有试用入口；文档里的限制和价格页冲突；任意地址都返回 200 并自称正式页；或把所有获客希望压在博客上，产品页却完不成任务。
- **acceptance_evidence**: 主路径每一步有对应页或明确缺口；试用或首次价值有可重复的操作说明；价格、退款和限制没有互相打架。
- **sources**: [Stripe：Get started](https://docs.stripe.com/get-started)；[Ahrefs：Product-led content](https://ahrefs.com/blog/product-led-content/)；[Ahrefs：AI 引荐落地页](https://ahrefs.com/blog/ai-search-traffic-by-page-type-ahrefs/)
- **maturity**: `general_method`

### M2-trust-pages


- **question**: 准备付钱或提交资料的人，能否核验卖什么、多少钱、出了问题怎么办？
- **principle**: 交易信任是转化基础，不是 SEO 装饰。最低集通常包括：产品或服务是什么、价格与币种、联系方式、退款或履约、隐私和限制。联系方式是读者能用的渠道，例如社区、公开账号或邮箱，不要求公开法律主体。这些渠道在不运行脚本时也要能读到，并且链接有效。缺这些会在真实任务中失败，即使搜索表现看起来正常。
- **applicable_when**: 有付费、注册、提交客户资料或签约动作时；或检查首页与结论文案是否过度承诺时。
- **actions**: 对照公开页列出上述说明是否存在、是否与事实记录一致、是否能从相关页到达。不能到达的入口记缺口。联系渠道以主人维护的设置为准，不在页面里另写一套。不要把支付渠道重构自动并入本轮。法务意见超出本方法时，标交接。
- **counterexample**: 宣传“立刻上线”却找不到退款或限制；价格只出现在广告里，网站写“联系我们”；邮箱只在脚本运行后才出现；页脚放着已经失效的邀请；或把 Stripe 清单当成全球法律意见。
- **acceptance_evidence**: 信任说明可在公开页核验，或明确标未提供；动态价格只指向事实记录，没有第二份手抄价。
- **sources**: [Stripe：网站清单](https://docs.stripe.com/get-started/checklist/website)
- **maturity**: `general_method`

---

## M3 事实与真实问题

## M3 事实与真实问题

Baseline IDs (pinned agent-readiness, not duplicated here): `M3-fact-cards`, `M3-question-sources`, `M3-question-page-map`.

### M3-page-intent


- **question**: 这条查询或问题现在该更新旧页、合并旧页，还是真的需要新页？
- **principle**: 先查已有页、其用途、索引或发现状态，再决定拆合。有无展示只是一个信号，必须结合意图、内容缺口、现页能否完成任务。没有搜索控制台数据时，仍可用公开页、客服原话和产品任务推进；缺展示不得写成“必须新建页”，也不得写成“已有页足够”。
- **applicable_when**: 从查询、销售原话或产品任务映射到页面时；尤其是有人主张“没展示就新开 URL”时。
- **actions**: 为每个优先问题写下：现页 URL 或无页、现页任务、内容缺口、已知的索引/发现证据或未接入。能靠更新或合并完成同一任务就不要新页。只有任务实质不同、内容不能共用时才新增。相关问题用主题结构组织，不按每个词造一页。
- **counterexample**: 无展示就批量新建；有展示就宣布旧页已赢；或没有 GSC 就停止全部内容研究。
- **acceptance_evidence**: 每个优先问题有去向和理由；无搜索数据的项标未知，仍有下一步；没有把词相同当成内容相同。
- **sources**: [HubSpot：主题与支柱页](https://knowledge.hubspot.com/content-strategy/pillar-pages-topics-and-subtopics)；[Google 生成式搜索优化指南](https://developers.google.com/search/docs/fundamentals/ai-optimization-guide)；[PostHog：SEO 写作手册](https://posthog.com/handbook/content/seo-guide)
- **maturity**: `general_method`

---

## M4 基线与测量设计

## M4 基线与测量设计

Baseline IDs (pinned agent-readiness, not duplicated here): `M4-frozen-set`, `M4-environment`, `M4-observation-window`.

### M4-question-generations


- **question**: 真实用户后来问的话和本轮冻结题不一样，能不能改题再报涨？
- **principle**: 旧轮题库、基线和原始回答必须保留适用边界。出题和优化的单位是意图组，不是单句：同一购买意图下放几种自然问法，并记下换一种问法后结论还成不成立。新的真实问法进入新版本，并重新取基线。合成监测题与真实用户原话重合低时，说明监测题不能代表市场，不说明旧证据作废。
- **applicable_when**: 收到客服原话、自报提问、搜索导出或新的 Agent 候选，并且已有一轮冻结题时；或准备下一轮题时。
- **actions**: 把新问法写入下一轮候选池，标上所属意图组和出处，以及它和旧题的关系。需要比较时，创建新的问题版本和新基线。报告里同时保留旧轮描述。不得为了更好看的数字改已采样题目。已冻结的一轮按原题复测。
- **counterexample**: 发现真实用户问法更有利，就替换旧题并声称同一轮提升；或用自选题上的高可见率代替市场结果。
- **acceptance_evidence**: 旧题原文和旧结果仍在；新题有独立版本和基线；来源类型可区分。
- **sources**: [PostHog 真实问题实践](https://newsletter.posthog.com/p/llms-are-picking-winners-heres-how)
- **maturity**: `general_method`

---

## M5 内容与独立信任

## M5 内容与独立信任

Baseline IDs (pinned agent-readiness, not duplicated here): `M5-original-content`, `M5-public-sources`, `M5-citation-sources`, `M5-page-change`.

### M5-core-asset


- **question**: 这一轮有没有一份别人能核验、能动手跟做的核心产物？
- **principle**: 信任来自真实演示、数据、案例、方法和经验，不是来自“权威口吻”。先做一份可复核的核心资产，再改编到网站和渠道。教程和工具页也可以有商业价值，前提是读者能用真实产品完成实际任务。无数据就不做评测页。
- **applicable_when**: 规划原创内容、站外贡献或“先写十篇博客”的请求时。
- **actions**: 选定一个真实任务，写出可重复步骤、条件、限制和失败时怎么办。保存原始证据：操作记录、样本范围、日期。再从这份资产改编首页说明、文档或一篇渠道稿。事实仍指向同一事实记录。
- **counterexample**: 没有操作就写“最佳实践评测”；或先批量生成多平台稿，核心产物还是空的。
- **acceptance_evidence**: 核心资产能被第三人按步骤复核或明确标演示条件；渠道稿没有多出资产里没有的优势。
- **sources**: [Ahrefs：Product-led content](https://ahrefs.com/blog/product-led-content/)；[Google 生成式搜索优化指南](https://developers.google.com/search/docs/fundamentals/ai-optimization-guide)；[姚金刚分析完整性框架](https://raw.githubusercontent.com/yaojingang/yao-geo-skills/main/skills/yao-geo-execution-roadmap/references/analysis-completeness-framework.md)
- **maturity**: `general_method`

### M5-comparison-fairness


- **question**: 比较或榜单是在帮读者选择，还是在互相输送名次？
- **principle**: 比较要有共同维度、对称事实和公开方法。榜单必须写清标准、数据集和日期。关联方或赞助来源可以存在，但必须披露，且不计独立证据。禁止互排第一、伪装独立评测。
- **applicable_when**: 写对比页、榜单、集成目录或引用第三方评测时。
- **actions**: 列出被比较对象、共同维度和每项事实来源。缺数据就写缺数据，不要补成领先。赞助、友情或同主体来源单独标注。读者应能看到自己适合哪一边，包括不选择我们。
- **counterexample**: 两家约定你第一我第一；用自己的博客当“独立第一名”；或只写对手缺点、把自己的限制藏起来。
- **acceptance_evidence**: 比较维度对称；方法或数据缺口可见；关联来源没有被写成独立背书。
- **sources**: [Google 垃圾内容政策](https://developers.google.com/search/docs/essentials/spam-policies)；[PostHog：SEO 写作手册](https://posthog.com/handbook/content/seo-guide)
- **maturity**: `general_method`

---

## M6 发布、发现与复测

## M6 发布、发现与复测

Baseline IDs (pinned agent-readiness, not duplicated here): `M6-publish-readback`, `M6-discovery`, `M6-retest`.

### M6-surface-separation


- **question**: 普通搜索、直接答案和生成回答的证据能不能放进同一个可见率分母？
- **principle**: 三类表面分开记录。官方 Google 生成式展示量和 Bing 引用量是各自来源行，不能相加，也不能塞进现有 AI 答案聚合器的分母。没有读取账户就标未接入，不是零。普通 SERP 永远不是模型回答。
- **applicable_when**: 导入 Search 控制台、Bing 工具、AI 采样或写品牌阶段报告时。
- **actions**: 为普通搜索、精选摘要或直接答案、生成回答、品牌反馈、业务各建独立行。官方展示/引用数据保持原口径。geo-measure 只聚合模型回答观察。平台、语言、检索状态不同就分开。
- **counterexample**: 把 Google AI 展示写进 AI 可见率；把 Bing 引用和 ChatGPT 提及相加；或把一次 google.com 网页结果标成模型回答。
- **acceptance_evidence**: 报告分栏；未接入账户没有被写成零展示；模型回答分母里没有普通 SERP。
- **sources**: [Google 生成式 AI 展示报告](https://support.google.com/webmasters/answer/16984139?hl=en)；[Bing AI Performance](https://blogs.bing.com/webmaster/February-2026/Introducing-AI-Performance-in-Bing-Webmaster-Tools-Public-Preview)；[Google 精选摘要](https://developers.google.com/search/docs/appearance/featured-snippets)
- **maturity**: `platform_docs`

---

## M7 来源、行为与业务

## M7 来源、行为与业务

Baseline IDs (pinned agent-readiness, not duplicated here): `M7-touchpoint`, `M7-identity`, `M7-self-report`, `M7-funnel`, `M7-money-views`.

This module has no additional owned entries.

## M8 复盘与下一轮

Baseline IDs (pinned agent-readiness, not duplicated here): `M8-review`, `M8-next-round`.

### M8-transferability


- **question**: 下一品牌或下一市场能复用什么，必须重新研究什么？
- **principle**: 方法、模板和检查可以迁移。定位、客户原话、价格、基线、案例和收入不能跨品牌或跨市场借用。一次实践即使成功，也只是一个案例。失败、不适用和缺数据都要保留，修改方法前不得改写旧结论。
- **applicable_when**: 结束一轮品牌工作、准备第二个品牌或第二个市场，或有人想把已有案例改名复用时。
- **actions**: 列出可迁移项（流程、记录形状、白帽边界）和不可迁移项（事实、题库、观测、业务窗口）。新品牌建立独立简报和工作记录。旧轮证据保持只读。方法若修订，用 pinned agent-readiness `templates/method-review.md`（安装后：`dependencies/agent-readiness/templates/method-review.md`）留下旧句。
- **counterexample**: 把一个品牌的客户理由抄到另一个品牌的定位里；或为了让第二轮好看而改第一轮题目。
- **acceptance_evidence**: 两个项目的事实和基线不相混；方法修订能指向旧句；失败项没有从记录里消失。
- **sources**: [PostHog 真实问题实践](https://newsletter.posthog.com/p/llms-are-picking-winners-heres-how)；[SearchPilot：SEO 与 GEO 实验不同](https://www.searchpilot.com/geo-a-b-testing-seo-and-geo-are-not-the-same)
- **maturity**: `general_method`

---

## M9 品牌项目范围

按需读取 `references/brand-project.md`。不要因为打开了品牌项目，就自动执行全部子能力。

## M9 品牌项目范围

按需读取 `references/brand-project.md`。不要因为打开了品牌项目，就自动执行全部子能力。

### M9-brand-scope


- **question**: 这个品牌项目服务哪个市场、处在什么阶段、哪些工作现在能做、哪些明确不做？
- **principle**: 先写品牌目标、业务市场、生命周期和成功证据，再选网站、搜索或分发动作。网站是载体之一。没有网站也可以先做客户研究和定位草案。当地门店、电商商品 feed、消费品大规模品牌追踪、付费媒介采买、商标法务，标成适用性分支或交接，不宣称已覆盖。
- **applicable_when**: 用户要做品牌建设、品牌续跑，或把“获客/定位/识别”和网站诊断混在一句里时。
- **actions**: 写下品牌、一个市场、当前阶段、本阶段成功证据、明确不做的行业动作。无网站且用户没有要求先建站时，进入研究而不是发明公开地址。用户只要求建网站时，走网站基础，不强迫先开品牌项目。单项审计、改 title、解释术语，不升级成品牌项目。
- **counterexample**: 把“做品牌但还没有网站”缩成建站任务；或把 URL 审计自动做成品牌扫描。
- **acceptance_evidence**: 范围能指出市场和阶段；不适用项写明；无网站研究草案不包含虚构域名。
- **sources**: [April Dunford：定位入门](https://www.aprildunford.com/post/a-quickstart-guide-to-positioning)；[Google 生成式搜索优化指南](https://developers.google.com/search/docs/fundamentals/ai-optimization-guide)
- **maturity**: `general_method`

### M9-one-brand-one-market


- **question**: 这份记录同时装了几个品牌、几个市场吗？
- **principle**: 一个品牌项目只服务一个品牌在一个市场。多触点（官网、文档、社区、邮件）可以列在简报的角色表里，但每个网站测量仍是各自的单站 round。两个品牌不能互借事实、价格、客户或基线。
- **applicable_when**: 建立或续跑品牌项目，或同一主人拥有多个产品名时。
- **actions**: 在简报里写死品牌名和市场。其他域名或入口只标注角色和指针。需要做网站测量时，引用已有 `experiment.json`，不把两个站点写进同一个 experiment。第二市场新建项目。
- **counterexample**: 同一份工作记录里混用两个市场的客户原话；或让一个 experiment 同时代表两个品牌。
- **acceptance_evidence**: 项目身份只有一个品牌加一个市场；多触点都是引用，不是第二套动态事实。
- **sources**: [April Dunford：定位入门](https://www.aprildunford.com/post/a-quickstart-guide-to-positioning)
- **maturity**: `general_method`

### M9-project-records


- **question**: 品牌工作最少要留下哪些可读记录，才够下次续跑？
- **principle**: 第一版只用两个 Markdown 载体：品牌简报和工作记录。简报保存定位、关系、表达和假设。工作记录保存阶段、成果、授权、站外资产和验收指针。产品价格等动态事实仍引用事实源，不复制成第二份真相。网站动作状态只链接已有 actions/coverage，不手工复写发布状态。
- **applicable_when**: 开始品牌项目、换会话续跑，或有人建议先建品牌数据库时。
- **actions**: 从 `templates/brand-brief.md` 和 `templates/brand-work.md` 建立或更新记录。动态事实写指针。站外资产写在工作记录里，不要改到站来源问卷的职责。pinned agent-readiness `templates/source-survey.md` (after vendor: `dependencies/agent-readiness/templates/source-survey.md`) 仍只用于已经到站并且愿意回答的人。
- **counterexample**: 把价格抄进简报后与事实记录不一致；用到站问卷登记外链；或没有工作记录就宣称项目可续跑。
- **acceptance_evidence**: 两份载体都能独立打开；续跑能从记录看到阶段和下一步；动态事实没有第二份正文。
- **sources**: [Linear：Brand Guidelines](https://linear.app/brand)；[姚金刚分析完整性框架](https://raw.githubusercontent.com/yaojingang/yao-geo-skills/main/skills/yao-geo-execution-roadmap/references/analysis-completeness-framework.md)
- **maturity**: `general_method`

### M9-authorization


- **question**: 哪些动作已经有权继续，哪些必须停，要不要每次再问一遍？
- **principle**: 授权继承，不仪式确认。读取公开资料、整理已有授权材料、写方案和草稿，由 Agent 完成。访谈邀请、客户消息、社区发帖、公开发布、生产部署、实际付款、分析账户接入，沿用本会话或对应项目已有授权。缺授权时只暂停该动作，不阻塞其他可做工作。
- **applicable_when**: 任何会发到站外、改生产、接触真实客户或接入账户的步骤。
- **actions**: 在工作记录里分开写：已有授权可继续、本动作缺授权、被拒绝。已有明确授权不再索要许可。未授权发布停在可审草稿。
- **counterexample**: 每次保存草稿都问“是否允许我写作”；或没有发布授权却把草稿写成已发表。
- **acceptance_evidence**: 暂停项只影响该动作；已授权动作有继承记录；未发布项没有 URL 冒充发表。
- **sources**: [Google 垃圾内容政策](https://developers.google.com/search/docs/essentials/spam-policies)
- **maturity**: `general_method`

### M9-on-demand-modules


- **question**: 这次要不要把十个教学模块全部做完？
- **principle**: T1–T10 是学习顺序，不是运行器清单。只加载当前缺口需要的模块和参考。品牌资料缺失可以输出带假设的研究草案，不能要求一次填完几十项才开始。
- **applicable_when**: 规划品牌任务包、写阅读清单，或用户只问其中一件事时。
- **actions**: 根据当前阶段选择参考：编排读 `references/brand-project.md`，研究读 `references/brand-research.md`，表达读 `references/brand-expression.md`，分发读 `references/distribution-and-trust.md`。单项请求不打开品牌项目。
- **counterexample**: 改一个 title 却要求先完成客户访谈和识别资产调查；或把十章目录当成验收。
- **acceptance_evidence**: 阅读清单与当前缺口对应；未加载模块没有被标成失败。
- **sources**: [姚金刚分析完整性框架](https://raw.githubusercontent.com/yaojingang/yao-geo-skills/main/skills/yao-geo-execution-roadmap/references/analysis-completeness-framework.md)
- **maturity**: `general_method`

### M9-stage-completion


- **question**: 怎样才算这一阶段做完，怎样还不能宣布品牌整轮完成？
- **principle**: 建设验收与效果判断分开。阶段完成看约定范围是否执行、结果是否真实、下一步是否有依据。网站批次全完成但站外或研究任务未做，不能宣布品牌整轮完成。缺数据可交阶段报告，不能把完整业务环节标成完成。
- **applicable_when**: 主人问“品牌做完了吗”、写阶段报告或准备进入效果复盘时。
- **actions**: 对照工作记录的本阶段范围逐项勾选。分别报告研究、表达、网站、分发、测量。效果层没有数据就标未测。下一步必须能回到未完成项或新证据。
- **counterexample**: 首页已发布就宣布品牌建设完成；或把准备度分数当成品牌心智。
- **acceptance_evidence**: 完成判定引用范围清单；未做项可见；效果没有被建设进度替代。
- **sources**: [PostHog 真实问题实践](https://newsletter.posthog.com/p/llms-are-picking-winners-heres-how)
- **maturity**: `general_method`

---

## M10 客户、购买情境与定位

按需读取 `references/brand-research.md`。真实原话、查询数据和 Agent 候选必须分开。

## M10 客户、购买情境与定位

按需读取 `references/brand-research.md`。真实原话、查询数据和 Agent 候选必须分开。

### M10-customer-evidence


- **question**: 我们依据谁的原话做判断，这些话从哪来？
- **principle**: 观察成功、流失和未购买的人，不只问满意者。来源分层：客户或用户原话、销售/客服记录、站内搜索、授权查询导出、公开社区、Agent 生成候选。假设不能冒充“客户说”，也不能冒充搜索量。没有客户资料时，用已有公开证据推进，并列出要补的研究任务。
- **applicable_when**: 写定位草案、选题、或只有内部愿望没有客户证据时。
- **actions**: 为每条需求或顾虑写下出处、日期、对象类型（成功/流失/未买/内部）。原话单独保存，不改写成更整齐的优点。没有访谈授权就不要生成假访谈。Agent 候选明确标候选。
- **counterexample**: 编造“客户说接入只要五分钟”；只访谈粉丝；或把语言模型的市场想象写成调研结论。
- **acceptance_evidence**: 每条被采用的需求能回到来源类型；假设清单可见；无客户记录时没有“客户说”。
- **sources**: [April Dunford：定位入门](https://www.aprildunford.com/post/a-quickstart-guide-to-positioning)；[PostHog 真实问题实践](https://newsletter.posthog.com/p/llms-are-picking-winners-heres-how)
- **maturity**: `general_method`

### M10-buying-situations


- **question**: 需求出现时，买方在做什么、受什么约束、会想到哪类办法？
- **principle**: 购买情境是品牌被想起的时机，不是口号。B2B 里常见触发是任务失败、工具更换、合规要求、人员变化或预算窗口。内容选题要覆盖这些情境。几个访谈不能写成心智份额；人的记忆也不能换成模型提及率。
- **applicable_when**: 做客户研究、选内容主题、或设计品牌识别检查时。
- **actions**: 从已有证据列出少量具体情境，不强制数量：谁、在哪、要完成什么、当时会找什么。用原话或观察支持每一条，没有证据的标假设。把情境映射到可能的页面或渠道，不要求每个情境一张新页。
- **counterexample**: 只用“我们更智能”覆盖所有时机；或把三次友好访谈写成品类进入份额。
- **acceptance_evidence**: 情境表可被主人看懂；每条有来源或假设标记；没有把 LLM 提及当成真人想起。
- **sources**: [Ehrenberg-Bass：B2B 品类进入情境](https://marketingscience.info/news-and-insights/category-entry-points-in-a-business-to-business-b2b-world)
- **maturity**: `general_method`

### M10-alternatives


- **question**: 没有我们的时候，他们现在用什么办法，为什么还能过得去？
- **principle**: 定位从实际替代方案推导，不从愿望表推导。替代包括竞品、通用工具、手工流程和什么都不做。先写清替代方案的代价和残留痛苦，再写我们可证明的不同。
- **applicable_when**: 定位研究、比较页或“我们的优势”文案出现时。
- **actions**: 列出替代方案、谁在用、完成同一任务的步骤、费用或时间、失败点。证据优先来自流失和未购买对象。不要把内部功能清单倒推成客户曾经比较过的选项。
- **counterexample**: 先写完口号再补一个假想对手；或把从未进入考虑集的大品牌硬拉进对比。
- **acceptance_evidence**: 替代方案表有来源；至少包含一种非软件或“什么都不做”的办法；优势能指回替代方案的具体缺口。
- **sources**: [April Dunford：定位入门](https://www.aprildunford.com/post/a-quickstart-guide-to-positioning)
- **maturity**: `general_method`

### M10-positioning


- **question**: 对最合适的人，我们因为什么可证明的不同而被考虑？
- **principle**: 顺序是：实际替代方案 → 可证明的不同能力 → 对客户的价值 → 最合适的人群 → 市场类别。类别最后选。定位不是 slogan，也不是让 AI 必须推荐我们。证据不足就保留草案和待补证，不让模型打分盖章。
- **applicable_when**: 写简报中的定位草案、首页一句话，或主人要求“先给句广告语”时。
- **actions**: 按上述顺序填写草案。每句价值都指向可核对证据或明确假设。适合与不适合分开写。需要主人确认的定位句子单独列出，不把未确认草案写成已发布主张。
- **counterexample**: 先写出“领先的新一代平台”再找案例；或把尚未证实的优势写进首页。
- **acceptance_evidence**: 草案能看出替代方案和证据指针；未证实项仍是假设；没有定位分数。
- **sources**: [April Dunford：定位入门](https://www.aprildunford.com/post/a-quickstart-guide-to-positioning)
- **maturity**: `general_method`

### M10-fit-boundary


- **question**: 谁适合现在被服务好，谁应该被明确劝退？
- **principle**: 短期资源集中在能服务好的客户，同时保留稳定识别资产给未来情境。不适合的对象写清楚，避免销售和内容把他们当成首要读者。劝退是产品诚实，不是攻击。
- **applicable_when**: 定位草案、定价页、文档“不适合”或销售话术需要边界时。
- **actions**: 写出可识别的适合特征和不适合特征，各配一条证据或假设。内容选题优先服务适合对象的购买情境。不适合对象若仍会搜到我们，页面应能让他们自己退出。
- **counterexample**: 声称适合所有人；或把不适合的原因写成对手辱骂。
- **acceptance_evidence**: 适合/不适合都能被未参与讨论的人看懂；劝退理由可核对或标假设。
- **sources**: [April Dunford：定位入门](https://www.aprildunford.com/post/a-quickstart-guide-to-positioning)；[Ehrenberg-Bass：B2B 品类进入情境](https://marketingscience.info/news-and-insights/category-entry-points-in-a-business-to-business-b2b-world)
- **maturity**: `general_method`

---

## M11 品牌关系与表达

按需读取 `references/brand-expression.md`。关系未确认也可以研究各自客户与事实。

## M11 品牌关系与表达

按需读取 `references/brand-expression.md`。关系未确认也可以研究各自客户与事实。

### M11-brand-relations


- **question**: 对外出现的名字里，哪个是品牌、哪个是公司、哪个是产品、哪个是个人？它们是不是母子关系？
- **principle**: 法定主体、品牌名、产品名、个人名和官网可以不同。名称关系由主人确认，Agent 不得从同一主人、同一邮箱或同一设计风格自动裁定母子品牌或“旗下”。关系未确认时，对外只写各自负责什么，暂停依赖该关系的陈述，不停止各自的事实研究。
- **applicable_when**: 简报里有多个名字、共用视觉、或有人要求写“XX 旗下”时。
- **actions**: 列出每个公开名字、角色、官方入口和已确认关系。未确认项提出候选表达，等主人决定。两个品牌的事实、题库和收入保持分离。
- **counterexample**: 因为同一主人就写母公司；或关系未定就暂停全部研究。
- **acceptance_evidence**: 关系栏只有已确认事实或明确未确认；没有自动母子结论。
- **sources**: [Linear：Brand Guidelines](https://linear.app/brand)
- **maturity**: `general_method`

### M11-identity-assets


- **question**: 到了该想起或认出我们的时候，名字、视觉和说法能不能被认出来？
- **principle**: 识别资产要少而稳定：规范名、允许的别名、官网、标志、关键色、一句能核对的能力。自己觉得好看或同行都用某种配色，不证明已有辨识度。识别调查和网站准备度是不同工作。
- **applicable_when**: 建立表达规范、检查多触点是否同一套身份，或有人要把每次生成都换一套风格时。
- **actions**: 记录规范名、禁止写法、标志用途、不能做的事。检查首页、文档、渠道稿是否同一套名字和官方入口。缺调查时，识别效果标未测，不编“已经深入人心”。
- **counterexample**: 同一产品在首页、文档和社区用三种拼写；或把内部喜欢的新配色当成已验证资产。
- **acceptance_evidence**: 资产清单可执行到两个以上触点；未测识别没有写成已验证。
- **sources**: [Ehrenberg-Bass：品牌识别资产](https://marketingscience.info/learn-with-us/commercial-research/distinctive-asset)；[Linear：Brand Guidelines](https://linear.app/brand)
- **maturity**: `general_method`

### M11-expression-system


- **question**: 换一个触点时，语气和称呼还是不是同一个品牌？
- **principle**: 最小表达规范要能指导至少两种触点，例如官网与一篇社区稿。规范管理名称、标志和使用场景，不要求复制某家公司的视觉风格。每次生成一套新品牌等于没有品牌。
- **applicable_when**: 写首页、文档、招聘页、社区帖或授权渠道改编时。
- **actions**: 在简报里写下称呼、语气、禁用夸大词、如何讲限制、如何署名。渠道改编只改长度和场合，不改事实。新触点先对照规范，再写稿。
- **counterexample**: 官网克制、广告稿保证排名；或为每个平台重新起一个产品外号。
- **acceptance_evidence**: 两份不同触点的草稿能对照同一规范；事实差异为零或已指向事实更新。
- **sources**: [Linear：Brand Guidelines](https://linear.app/brand)；[PostHog：SEO 写作手册](https://posthog.com/handbook/content/seo-guide)
- **maturity**: `general_method`

### M11-claim-evidence


- **question**: 这句对外主张现在能不能指到可核对的证据？
- **principle**: 有声明但无证据的优势不能发布。主张写在简报里，证据写指针，动态事实仍以事实记录为准。重新核验不是正文更新，也不能为了新鲜感改日期。
- **applicable_when**: 首页、价格、比较、案例或渠道稿出现“最快、唯一、保证”这类句子时。
- **actions**: 为每条拟发布主张写证据指针和状态：已核验、待核验、假设、禁止。禁止项和冲突项不进对外正文。证据过期就撤回主张，不改日期装新。
- **counterexample**: “节省 80% 时间”没有任何样本；或把去年的案例改成今年日期。
- **acceptance_evidence**: 拟发布主张都能跟到来源或被撤下；假设没有混进已确认栏。
- **sources**: [Google 生成式搜索优化指南](https://developers.google.com/search/docs/fundamentals/ai-optimization-guide)；[Google 垃圾内容政策](https://developers.google.com/search/docs/essentials/spam-policies)
- **maturity**: `platform_docs`

### M11-touchpoint-consistency


- **question**: 同一条产品事实，在首页、文章和渠道稿里是不是同一句话的意思？
- **principle**: 格式可以不同，事实必须同一批。人和 AI 看到同一批事实。更新一次动态事实后，要核验引用它的触点，而不是只改一页。
- **applicable_when**: 价格、限制、兼容性、退款或命名发生变化，或同时生产多种稿件时。
- **actions**: 把首页、文档、价格、政策和给 AI 的说明里的同一类事实抽出来对照，至少包括接口地址、兼容方式、价格单位、退款和联系方式。更新事实记录后检查引用它的触点。未改到的触点标过期。说法不一致就列出来，不取平均，也不为了渠道口吻发明第二套数字。
- **counterexample**: 首页写按月计费，社区稿写按年更便宜却没有事实来源；条款只写一种接入方式，文档却写了两种；或只改 schema 不改可见正文。
- **acceptance_evidence**: 同一事实的公开说法可对上同一来源；过期触点被列出而不是假装已同步。
- **sources**: [Google 生成式搜索优化指南](https://developers.google.com/search/docs/fundamentals/ai-optimization-guide)；[Stripe：Get started](https://docs.stripe.com/get-started)
- **maturity**: `general_method`

---

## M12 分发、关系与声誉

按需读取 `references/distribution-and-trust.md`。站外资产记在品牌工作记录，不记在到站来源问卷。

## M12 分发、关系与声誉

按需读取 `references/distribution-and-trust.md`。站外资产记在品牌工作记录。到站来源问卷仍属于 pinned agent-readiness。

### M12-channel-selection


- **question**: 受众实际出现在哪里，我们要不要出现，出现时贡献什么？
- **principle**: 到相关受众真实出现的地方贡献有用内容，而不是先铺全网日历。渠道选择依据受众情境，不依据“SEO 必须发外链”。第一轮通常选一个主要站外渠道，完成一份核心资产后再改编。发帖数量不是权威。
- **applicable_when**: 规划站外工作、changelog、集成目录、社区或研究发表时。
- **actions**: 写下具体候选、那里的受众、可贡献的产物和所需授权，并说明为什么适合。第一轮只做一个主渠道。目录只提交与受众相关的少数几个，不做批量自动提交。没有授权就停在草稿。不自动外联，不代买位置。
- **counterexample**: 还没有核心资产就生成十个平台的空稿；把未去过的论坛写成已运营；或批量向无关目录自动提交。
- **acceptance_evidence**: 渠道表有受众理由和授权状态；未发布项没有 URL。
- **sources**: [Ahrefs：Product-led content](https://ahrefs.com/blog/product-led-content/)；[HubSpot：主题与支柱页](https://knowledge.hubspot.com/content-strategy/pillar-pages-topics-and-subtopics)
- **maturity**: `general_method`

### M12-offsite-assets


- **question**: 每一份站外材料现在是什么状态，它支持哪句主张？
- **principle**: 每条站外资产至少记录用途、目标受众、支持的主张、第一方/关联方/独立来源、披露、URL 或草稿、时间、证据和反馈。缺 URL 表示未发布。关联方文章不伪装独立背书。到站来源问卷不承担这张表。
- **applicable_when**: 准备或已经在站外发表、被转载、被评论时。
- **actions**: 在工作记录里增改一行，不复制正文到第二份真相库。发布后补 URL 和读回。反馈和纠错链到同一行。
- **counterexample**: 用到站问卷登记外链；或把友情文章写成“独立媒体评测”。
- **acceptance_evidence**: 每条站外资产字段完整或明确待补；来源类型与披露一致。
- **sources**: [Google 垃圾内容政策](https://developers.google.com/search/docs/essentials/spam-policies)；[Ahrefs：品牌相关性研究](https://ahrefs.com/blog/ai-overview-brand-correlation/)
- **maturity**: `general_method`

### M12-disclosure


- **question**: 读者能不能看出这是我们自己写的、合作写的，还是别人独立写的？
- **principle**: 身份和关系要透明。赞助、付费、友情、同主体、员工账号必须披露。透明赞助可以有合法价值，但不是买排名。链接属性、关系相关性和受众价值分别核对。
- **applicable_when**: 客座文章、集成目录、联合研究、付费广告或员工在社区发言时。
- **actions**: 在资产行写披露文案和关系类型。自己的身份材料用第一方。需要 `sponsored` 或等价披露时，交给宿主按平台规则执行。本方法不代操作账户。
- **counterexample**: 员工马甲冒充独立用户；付费稿不披露；或把披露过的赞助当成独立证据。
- **acceptance_evidence**: 关系类型可区分；独立证据栏没有混入关联来源。
- **sources**: [Google 垃圾内容政策](https://developers.google.com/search/docs/essentials/spam-policies)
- **maturity**: `platform_docs`

### M12-feedback-correction


- **question**: 有人指出错误、过期或伤害时，我们改了什么，公开结果在哪？
- **principle**: 处理反馈、错误和过期信息是声誉工作。能核验的纠错优先于辩解。过期事实按事实记录更新，并核验引用它的触点。投诉不足以证明市场趋势，但足以启动核对。
- **applicable_when**: 收到更正请求、产品变更、负面讨论或发现过期页时。
- **actions**: 记录反馈来源、指向的事实、核对结果、改动指针和公开说明位置。未核实前不把批评改写成我们的新优势。需要发布时走授权。
- **counterexample**: 默默改掉错误却声称“从未有过这个问题”；或把一条投诉写成行业共识。
- **acceptance_evidence**: 纠错链可跟随；过期触点被列出；未核实项保持未核实。
- **sources**: [Google 生成式搜索优化指南](https://developers.google.com/search/docs/fundamentals/ai-optimization-guide)；[PostHog：SEO 写作手册](https://posthog.com/handbook/content/seo-guide)
- **maturity**: `general_method`

### M12-link-judgment


- **question**: 这条链接或这组页面是在帮助读者，还是在操纵发现？
- **principle**: 白帽判断看目的、真实性、规模和披露。购买传权链接、交换第一名、组织刷点击、注入隐藏指令，拒绝。相关内链、页脚政策入口、有真实用途的模板页，不自动判违规。Google 规则不扩写为所有平台统一算法。
- **applicable_when**: 规划内链、页脚、模板页、目录提交、客座链接或有人提议买链时。
- **actions**: 写下链接目的和读者任务。相关且可到达的内链保留。规模化同质页、互排榜单、购买传权链记录为拒绝。不能确定时标未知并停在该动作，不扩大打击面。
- **counterexample**: 因为有页脚链接就判整站作弊；或把“五条内链”写成硬规则；或购买首页互链。
- **acceptance_evidence**: 拒绝项有具体操纵理由；保留的模板页或互链有读者用途说明。
- **sources**: [Google 垃圾内容政策](https://developers.google.com/search/docs/essentials/spam-policies)；[Google 生成式搜索优化指南](https://developers.google.com/search/docs/fundamentals/ai-optimization-guide)
- **maturity**: `platform_docs`

---

## M13 转化、留存与分层证据

按需读取 pinned agent-readiness `references/business-attribution.md` (after vendor)。激活和留存是项目定义，不是注册的别名。

## M13 转化、留存与分层证据

激活和留存是项目定义，不是注册的别名。网站、搜索、AI 与业务证据分别看，不合成总分。业务归因细则在 pinned agent-readiness 的业务参考里。

### M13-activation


- **question**: 这个项目里，怎样才算用户第一次得到了承诺中的价值？
- **principle**: 激活必须绑定真实产品事件，而不是把注册、加购或打开首页当成成功使用。不同产品的激活不同：一次成功调用、一份导出的客户文件、一次完成的工作流。优先用已有业务记录证明，不让代理为了补证据去付费调用。没有身份链接时，只报事件量。同一订单的多触点不重复计算成功。
- **applicable_when**: 定义项目成功、看漏斗或把“已经有注册”写成品牌胜利时。
- **actions**: 在简报或工作记录写下激活事件、证据来源和排除项（测试、内部、未完成）。能读到业务记录时，用第一次成功、成功率和对应账单，不另发付费请求。付费探测需要单独授权，失败不能写成已激活。报告时与注册、付款分开。前端点击不是终态。
- **counterexample**: 把注册数称为激活；同一个人三次导出算三个激活却又拿去当用户转化率超过百分之百；或一次超时的付费探测被写成首次价值已验证。
- **acceptance_evidence**: 激活定义能指向产品事件；注册、激活、付款三列可分开读。
- **sources**: [PostHog 漏斗](https://posthog.com/docs/product-analytics/funnels)；[Stripe：Get started](https://docs.stripe.com/get-started)
- **maturity**: `general_method`

### M13-retention


- **question**: 同一批达到可比成熟度的人，后来还在不在用？
- **principle**: 留存观察必须同群体、同成熟度。不要拿 30 天老用户对比只观察 3 天的新用户。退款跟原订单走。没有业务数据时标未知，不是零。激活成功不等于已经留存，也不等于已经产生收入。
- **applicable_when**: 报告留存、复购、续费或“用户很喜欢”时。
- **actions**: 写下群体定义、成熟度窗口和截至时间。分别报告仍在使用、沉默、退款。缺导出就停在未测，继续其他研究。
- **counterexample**: 用当周新注册对比上季付费留存；或把一次好评写成留存率。
- **acceptance_evidence**: 比较组的成熟度写明；未知没有变成零；留存没有和激活混成一列。
- **sources**: [PostHog 留存](https://posthog.com/docs/product-analytics/retention)；[Yao 效果指标](https://github.com/yaojingang/yao-geo-skills/blob/201c0c45dcf09bb37bc46a467b4baf4d721db205/skills/yao-geo-effect-monitor/references/metrics-attribution.md)
- **maturity**: `general_method`

### M13-brand-feedback


- **question**: 这几个人能认出名字、能讲出考虑理由，能不能代表市场？
- **principle**: 品牌问卷和访谈是认知证据，不是市场调查替代品。记录招募来源、人数和问法。允许小样本得出描述性观察。LLM 说知道某个品牌，不代表真人认识。到站来源问卷只问已经到站的人如何到来，不承担品牌心智测量。
- **applicable_when**: 做识别检查、询问考虑理由、或有人想用几次访谈宣布心智胜利时。
- **actions**: 写下样本来源和偏差。名称/视觉识别、任务理解、考虑理由分行记录。不把结果加成准备度或 AI 可见率。需要市场推断时，标超出本方法并交接。
- **counterexample**: 访谈五个粉丝后写“目标市场已经记住我们”；或把模型回答中的品牌提及写成心智份额。
- **acceptance_evidence**: 样本边界可见；认知证据独立成行；到站问卷没有被改成品牌调查。
- **sources**: [Ehrenberg-Bass：品牌识别资产](https://marketingscience.info/learn-with-us/commercial-research/distinctive-asset)；[PostHog 真实问题实践](https://newsletter.posthog.com/p/llms-are-picking-winners-heres-how)
- **maturity**: `general_method`

### M13-metric-layers


- **question**: 品牌心智、网站准备度、搜索、AI 和业务，哪一层证明了什么？
- **principle**: 各层独立，不造总分。建设完成不要求所有指标上涨，但要求范围被执行、结果真实。相关不是因果。品牌搜索上涨不自动等于本轮造成。引用不是推荐。发帖数、域名评分、转载数不等于品牌权威。
- **applicable_when**: 写阶段报告、对外说明或有人要求一个品牌健康分时。
- **actions**: 按层列出可用证据、分母或未测。AI 回答要分开判定有没有提到品牌、有没有推荐、有没有引用官网、事实对不对。判定可以用当前主模型，也可以用专门做分类的小模型。先用同一批人工标注对照，再决定用哪一个；没有对照，不说某个判定器更准。判定器名称、规则版本和低置信度复核写入该轮记录。采样可用已登录的浏览器界面逐题新开会话，控制数量，原始回答全部保留。干预因素（折扣、模型变更、活动）记在旁边。没有对照就不写增量。用户看见的说明只讲各层分别说明什么，不讲内部字段名。
- **counterexample**: 把准备度、提及、展示和实付加成获客分；或用厂商文章里的增长倍数当本项目目标。
- **acceptance_evidence**: 报告无总分；每层有证据或未测；作者案例没有变成我们的结果。
- **sources**: [Ahrefs：品牌相关性研究](https://ahrefs.com/blog/ai-overview-brand-correlation/)；[Google 生成式 AI 展示报告](https://support.google.com/webmasters/answer/16984139?hl=en)；[PostHog 真实问题实践](https://newsletter.posthog.com/p/llms-are-picking-winners-heres-how)
- **maturity**: `general_method`

---

## Related contracts

- Owned brand orchestration: `references/brand-project.md`
- Brand research: `references/brand-research.md`
- Brand expression: `references/brand-expression.md`
- Distribution and trust: `references/distribution-and-trust.md`
- Method evidence kinds: `references/method-evidence.md`
- Method map: `references/method-map.json`
- Brand brief template: `templates/brand-brief.md`
- Brand work template: `templates/brand-work.md`
- Review template: `dependencies/agent-readiness/templates/method-review.md`
- Baseline 26 methods, site foundation, arrival-source survey, and GEO round records: pinned agent-readiness after vendor, under `dependencies/agent-readiness/`
