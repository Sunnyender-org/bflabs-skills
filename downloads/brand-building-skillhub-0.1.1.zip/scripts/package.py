#!/usr/bin/env python3
"""Vendor the pinned agent-readiness skillhub package and inspect this Skill."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from brand_building.packaging import (  # noqa: E402
    PackageError,
    assemble_method_book,
    build_skillhub_zip,
    dependency_status,
    list_sop_files,
    load_lock,
    read_sop_file,
    validate_archive,
    vendor_readiness,
    verify_vendored_dependency,
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "command",
        choices=["vendor", "zip", "all", "assemble-method-book", "status", "list", "read", "validate"],
    )
    parser.add_argument(
        "--readiness-checkout",
        type=Path,
        help="explicit local git checkout whose HEAD matches dependency-lock.json",
    )
    parser.add_argument("--output", type=Path, default=ROOT / "dist")
    parser.add_argument("--archive", type=Path, help="zip to validate")
    parser.add_argument("path", nargs="?", help="relative SOP path for read")
    args = parser.parse_args()
    try:
        if args.command == "status":
            payload = {"lock": load_lock(ROOT), "dependency": dependency_status(ROOT)}
            print(json.dumps(payload, indent=2, ensure_ascii=False))
            return 0
        if args.command == "list":
            for name in list_sop_files(ROOT):
                print(name)
            return 0
        if args.command == "read":
            if not args.path:
                raise PackageError("read requires a relative path under SKILL.md, references/, templates/, or evals/")
            sys.stdout.write(read_sop_file(args.path, ROOT))
            return 0
        if args.command == "validate":
            if args.archive is not None:
                print(json.dumps(validate_archive(args.archive, expected_lock=load_lock(ROOT)), indent=2))
            else:
                verify_vendored_dependency(ROOT)
                print(json.dumps({"status": "pass", "dependency": str(ROOT / "dependencies/agent-readiness")}, indent=2))
            return 0
        if args.command == "assemble-method-book":
            path = assemble_method_book(ROOT)
            print(json.dumps({"path": str(path), "status": "generated"}, indent=2))
            return 0
        if args.command in {"vendor", "all"}:
            if args.readiness_checkout is None:
                raise PackageError("pass --readiness-checkout <clean-pinned-checkout>; refusing latest")
            dest = vendor_readiness(args.readiness_checkout, ROOT)
            print(json.dumps({"vendored": str(dest), "status": "ok"}, indent=2))
        if args.command in {"zip", "all"}:
            archive = build_skillhub_zip(args.output, ROOT)
            print(json.dumps(validate_archive(archive, expected_lock=load_lock(ROOT)), indent=2))
        return 0
    except PackageError as exc:
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
