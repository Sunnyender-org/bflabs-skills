"""Owned method IDs versus the pinned agent-readiness baseline."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, List, Tuple


BASELINE_METHOD_IDS: Tuple[str, ...] = (
    "M1-purpose",
    "M1-whitehat",
    "M1-stage-metrics",
    "M2-site-foundation",
    "M2-information-architecture",
    "M2-action-entry",
    "M3-fact-cards",
    "M3-question-sources",
    "M3-question-page-map",
    "M4-frozen-set",
    "M4-environment",
    "M4-observation-window",
    "M5-original-content",
    "M5-public-sources",
    "M5-citation-sources",
    "M5-page-change",
    "M6-publish-readback",
    "M6-discovery",
    "M6-retest",
    "M7-touchpoint",
    "M7-identity",
    "M7-self-report",
    "M7-funnel",
    "M7-money-views",
    "M8-review",
    "M8-next-round",
)

OWNED_METHOD_IDS: Tuple[str, ...] = (
    "M1-seo-aeo-geo",
    "M2-user-path",
    "M2-trust-pages",
    "M3-page-intent",
    "M4-question-generations",
    "M5-core-asset",
    "M5-comparison-fairness",
    "M6-surface-separation",
    "M8-transferability",
    "M9-brand-scope",
    "M9-one-brand-one-market",
    "M9-project-records",
    "M9-authorization",
    "M9-on-demand-modules",
    "M9-stage-completion",
    "M10-customer-evidence",
    "M10-buying-situations",
    "M10-alternatives",
    "M10-positioning",
    "M10-fit-boundary",
    "M11-brand-relations",
    "M11-identity-assets",
    "M11-expression-system",
    "M11-claim-evidence",
    "M11-touchpoint-consistency",
    "M12-channel-selection",
    "M12-offsite-assets",
    "M12-disclosure",
    "M12-feedback-correction",
    "M12-link-judgment",
    "M13-activation",
    "M13-retention",
    "M13-brand-feedback",
    "M13-metric-layers",
)

ITEM_HEADING = re.compile(r"^### ([A-Z][0-9]+-[a-z0-9-]+)$", re.M)
ITEM_FIELDS = (
    "question",
    "principle",
    "applicable_when",
    "actions",
    "counterexample",
    "acceptance_evidence",
    "sources",
    "maturity",
)
ALLOWED_MATURITY = {
    "platform_docs",
    "general_method",
    "project_hypothesis",
    "case_observation",
    "multi_case_review",
    "revised",
}
TEACHING_IDS = tuple(f"T{index}" for index in range(1, 11))
FORBIDDEN_PUBLIC_MARKERS = (
    "beefapi",
    "bufflow",
    "global.beefapi.com",
)
PRIVATE_PATH = re.compile(r"/(?:Users|home)/[^\s`)]+", re.I)
FLOATING_PIN = re.compile(r"^(latest|origin/main|main|HEAD)$", re.I)


def parse_method_items(method_text: str) -> Dict[str, str]:
    matches = list(ITEM_HEADING.finditer(method_text))
    items: Dict[str, str] = {}
    for index, match in enumerate(matches):
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(method_text)
        items[match.group(1)] = method_text[start:end]
    return items


def method_ids_in(path: Path) -> List[str]:
    return list(parse_method_items(path.read_text("utf-8")))
