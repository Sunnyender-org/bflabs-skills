"""Repository and optional vendored-dependency paths."""

from __future__ import annotations

from pathlib import Path


def repository_root() -> Path:
    return Path(__file__).resolve().parents[2]


def dependency_root(root: Path | None = None) -> Path:
    return (root or repository_root()) / "dependencies" / "agent-readiness"


def dependency_lock_path(root: Path | None = None) -> Path:
    return (root or repository_root()) / "dependency-lock.json"


def baseline_method_path(root: Path | None = None) -> Path:
    return dependency_root(root) / "references" / "whitehat-method.md"


def owned_method_path(root: Path | None = None) -> Path:
    return (root or repository_root()) / "references" / "whitehat-method.md"


def geo_content_skill_path(root: Path | None = None) -> Path:
    return dependency_root(root) / "skills" / "geo-content" / "SKILL.md"


def geo_content_contract_path(root: Path | None = None) -> Path:
    return dependency_root(root) / "skills" / "geo-content" / "references" / "content-contract.md"


def geo_content_handoff_path(root: Path | None = None) -> Path:
    return dependency_root(root) / "skills" / "geo-content" / "references" / "brand-handoff.md"
