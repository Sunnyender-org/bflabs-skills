# Fictional brand-project example

This folder is a complete, anonymous, invented project. It is not a real company, not a customer, and not a measurement result. Do not copy its product facts onto a live brand.

The two working files are `brand-brief.md` and `brand-work.md`. They show a brand that started with no website, still has unverified hypotheses, and must not be marked complete after a later site batch.

There is no Search Console export and no interview set large enough to represent a market. The records proceed with public evidence and labeled guesses. Unknown stays unknown.
